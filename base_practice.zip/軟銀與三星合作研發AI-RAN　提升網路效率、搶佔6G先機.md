---
新聞來源: "DIGITIMES"
published: 2025-10-29
---
# 軟銀與三星合作研發AI-RAN　提升網路效率、搶佔6G先機
[![軟銀與三星合作研發AI-RAN解決方案與6G的新技術。法新社](https://img.digitimes.com/newsimg/2025/1029/736239-1-27kut.jpg)](https://img.digitimes.com/newsimg/2025/1029/736239-1-27kut.jpg)

軟銀與三星合作研發AI-RAN解決方案與6G的新技術。法新社

 日本電信商軟銀（SoftBank）宣布已與南韓三星電子（Samsung Electronics）在AI-RAN領域的合作達成協議，並已在2025年10月簽署了合作備忘錄（MOU）。

根據日經新聞（Nikkei）、ITmedia報導與官網資料，軟銀於10月24日宣布，將與三星電子展開利用人工智慧（AI）技術於行動通訊網路的共同研究。雙方將聚焦於結合行動基地台與AI基礎設施的AI-RAN相關技術研發。此次合作包括下一代通訊標準6G實用化、AI for RAN、AI and RAN，以及運用軟銀研發中的生成式AI基礎模型「Large Telecom Model」在內的四大研究領域。

雙方的研發合作，是為了推進通訊與AI的融合，以提升通訊網路效率並創造新市場機會。這項合作並未設定明確期限，且未來有可能在研究成果商業化方面持續合作。

雙方特別關注被視為6G潛在頻段的7GHz頻帶，將進行現場驗證與使用案例探討。

在「AI for RAN」計畫中，重點放在物理層（Layer 1）引入AI的效果，期望達到RAN的效率提升與優化。此外，也將進行「AI and RAN」的研發與評估，藉由共用AI與RAN設備，提高資源利用率。

軟銀正在開發適用於通訊產業的AI基礎架構「Large Telecom Model」，並將利用大型語言模型（LLM）驅動的AI，推動網路優化工作流程的變革。雙方還將運用Large Telecom Model，設法達成資料的安全互通與功能提升，並致力於確立業界標準。

軟銀原本就已規劃，從2026年起向海內外電信營運商，提供AI-RAN服務，2024年已聯手美國NVIDIA等，成立推動該技術實用化的業界團體AI-RAN Alliance，成員包括三星電子及微軟（Microsoft）等業者。

責任編輯：蔡雨婷

# 資料來源
2025/10/29: [軟銀與三星合作研發AI-RAN　提升網路效率、搶佔6G先機](https://www.digitimes.com.tw/tech/dt/n/shwnws.asp?id=0000736239_ZDX1JKWR425VXK8X27KUT) 