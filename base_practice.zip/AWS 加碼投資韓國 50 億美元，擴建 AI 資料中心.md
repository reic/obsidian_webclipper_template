---
新聞來源: "TechNews 科技新報"
published: 2025-10-29
---
# AWS 加碼投資韓國 50 億美元，擴建 AI 資料中心
亞馬遜網路服務（AWS）宣布 2025~2031 年，投資約 50 億美元在韓國建立新人工智慧（AI）資料中心，將 AWS 當地總投資推升至超過 90 億美元，成為韓國雲端服務領域最大規模的綠地投資計畫。

此次新增的AI資料中心將設於仁川與京畿道，配合今年六月AWS與韓國大型企業SK集團合作推動的4億美元烏山AI專區設施，該專區預計於2027年啟用，首階段目標達成100兆瓦（MW）容量，長遠目標更計畫擴展至1吉瓦（GW），將成為全球最大型資料中心之一。

AWS副總裁暨亞太區總經理Jaime Valles表示，這項投資顯示AWS對韓國成為全球AI重鎮的長期承諾，並致力於透過世界級基礎設施推動韓國技術進步。AWS同時致力支援韓國企業運用包括機器學習、Trainium與Inferentia等專業AI硬體，打造穩定且可擴展的AI運算平台。

在韓國總統李在明的亞洲太平洋經濟合作會議（APEC）會議中，AWS執行長Matt Garman強調中國投資計畫，認為韓國在AI領域具備強勁成長潛力，AWS將持續加大投入促進技術發展。李總統表示，此舉將強化國家AI生態系統，推動「AI高速公路」建設，促使AI技術更廣泛應用於產業和研究領域，並期望AWS與本地企業深化合作，打造多元產業共榮格局。

AWS於2017年以來已為韓國培育超過30萬名雲端人才，並透過各類教育合作強化下一代科技人才基礎。此次投資亦為亞太地區14國共計400億美元投資計畫的一部分，預期將為區域帶來超過450億美元的經濟效益。

- [Amazon Web Services Plans Additional $5 Billion AI Investment in South Korea](https://www.wsj.com/tech/ai/amazon-web-services-plans-additional-5-billion-ai-investment-in-south-korea-84802e84?mod=Flipboard)
- [AWS pledges 7 trillion won to boost South Korea AI and cloud infrastructure](https://biz.chosun.com/en/en-it/2025/10/29/Q4STHP67QBDFTKKKW3XIHFQHGU/)
- [SK and Amazon Launch $5 Billion AI Data Center Deal—A New Era for Cloud and AI Infrastructure](https://blog.bestai.com/sk-and-amazon-launch-5-billion-ai-data-center-deal-a-new-era-for-cloud-and-ai-infrastructure/)
- [AWS to Invest $5 Billion in South Korean AI Data Centers by 2031](https://www.indexbox.io/blog/aws-to-invest-5-billion-in-south-korean-ai-data-centers-by-2031/)
- [Breaking: Amazon to Invest $5 Billion in South Korea AI Data Centers](https://www.chosun.com/english/national-en/2025/10/29/JXTKST4YLVDQ3MQA47FGS23RLI/)
- [AWS, global firms to invest $9 bil. in Korea to bolster AI, high-tech industries](https://www.koreatimes.co.kr/business/apec2025/20251029/aws-pledges-record-breaking-5-bil-investment-for-new-ai-data-centers-in-korea)
- [AWS Building New Data Center in Korea’s Incheon](https://w.media/aws-building-new-data-center-in-koreas-incheon/)
- [AWS Partners With SK Group to Build AI Data Center in S. Korea](https://www.govconexec.com/2025/06/aws-sk-collaborate-on-ai-data-center/)

（首圖來源：[Flickr/Web Summit](https://www.flickr.com/photos/websummit/51682363925/) CC BY 2.0）

### 延伸閱讀：

- [亞馬遜揭露 AWS 故障原因，自動化程序存在缺陷](https://technews.tw/2025/10/27/how-the-aws-outage-happened/)
- [AWS 斷線波及全球企業，亞馬遜稱雲端服務恢復運作](https://technews.tw/2025/10/21/aws-recover/)

# 資料來源
2025/10/29: [AWS 加碼投資韓國 50 億美元，擴建 AI 資料中心](https://technews.tw/2025/10/29/aws-ai/) 