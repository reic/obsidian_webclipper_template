---
新聞來源: CTIMES
published: 2025-10-27
---
# CTIMES/SmartAuto - NVIDIA於ROSCon擴大開源貢獻 加速ROS 2實體AI開發:機器人,NVIDIA
在全球機器人開發者盛會 ROSCon 上，NVIDIA宣布一系列針對機器人作業系統（ROS）的重大開源貢獻，加速「實體 AI」的發展，並鞏固ROS 2作為高效能框架的地位。

| [![](https://ctimes.com.tw/news/2025/10/27/2006174390S.jpg)](https://ctimes.com.tw/news/2025/10/27/2006174390.jpg) |
| --- |
| /news/2025/10/27/2006174390S.jpg |

為推動高效能機器人開發，NVIDIA宣布全力支援開源機器人聯盟（OSRA）新成立的「實體AI特別興趣小組」，專注於即時機器人控制與AI加速處理。

技術方面，NVIDIA宣布將「GPU 感知抽象層」（GPU-aware abstractions）直接貢獻給ROS 2核心。使ROS 2框架能原生理解並高效管理GPU資源，確保在AI任務中獲得一致的高速運算效能，並使其能跟上未來硬體的創新步伐。

針對開發者，NVIDIA亦開源了內部效能監測工具「Greenwave Monitor」，以協助開發者快速找出系統瓶頸。同時，NVIDIA正式發布Isaac ROS 4.0，這套GPU加速函式庫與AI模型合集，現已可在NVIDIA Jetson Thor平台上運行，為機器人操控與移動任務提供強大支援。

NVIDIA 的開源技術已獲得業界廣泛採用。包括 Intrinsic、AgileX Robotics、ROBOTIS 及 Stereolabs 在內的多家合作夥伴，正利用 NVIDIA Jetson 平台與 Isaac Sim 模擬工具，加速其新一代機器人的開發與部署。NVIDIA 致力於為開源社群提供從模擬到部署的完整平台，推動實體 AI 的未來。

# 資料來源
2025/10/27: [CTIMES/SmartAuto - NVIDIA於ROSCon擴大開源貢獻 加速ROS 2實體AI開發:機器人,NVIDIA](https://ctimes.com.tw/DispNews-tw.asp?O=HK9ARBYWZW6SAA00NL) 