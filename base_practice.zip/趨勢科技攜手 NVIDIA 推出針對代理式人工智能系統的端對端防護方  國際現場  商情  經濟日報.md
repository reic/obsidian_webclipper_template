---
新聞來源: "經濟日報"
published: 2025-11-05
---
# 趨勢科技攜手 NVIDIA 推出針對代理式人工智能系統的端對端防護方 | 國際現場 | 商情 | 經濟日報

#### *從基礎架構到應用層全面擴展代理式人工智能保安防護*

香港 - Media OutReach Newswire - 2025年11月5日 - 全球網絡保安方案領導廠商趨勢科技（東京證券交易所股票代碼：4704 ）宣佈與 NVIDIA BlueField 展開全新整合，將防護直接嵌入數據中心層面，為人工智能工廠提供更安全且具擴展性的防護。此全新方案讓企業能更快部署人工智能，同時降低多租戶人工智能雲環境中的風險，並符合嚴格的合規要求。

  
了解 **Trend Vision One™ Endpoint Security** 與 **NVIDIA BlueField DPU** 的整合方案：https://www.trendmicro.com/zh\_hk/business/ai/factory.html  
  
**NVIDIA BlueField** **資料處理單元是一款專為協助中央處理器分擔、加速及隔離基礎架構與保安任務而設計的處理器。**Trend Vision One™ Endpoint Security**（****AI Factory** **EDR****）**部署於 NVIDIA BlueField 上，能蒐集並監控主機與網絡資訊，並與趨勢科技威脅情報進行關聯分析，以偵測可疑行為。除了與 BlueField 整合外，趨勢科技也是首批通過 NVIDIA RTX PRO Server 驗證的資訊保安廠商之一，為人工智能工廠帶來專為企業級環境打造的資訊保安防護。  
  
此外，趨勢科技方案也被納入 **NVIDIA AI Factory for Government** 參考設計中，將人工智能工廠延伸至聯邦機構及高安全需求單位。該設計提供完整組合、端對端的部署指引，協助受監管產業在滿足合規要求的同時，也可安全地部署人工智能工作負載。  
  
趨勢科技平台暨業務長金敬秀表示：「代理式人工智能將開啟生產力、效率與商業敏捷性的全新時代，但前提是必須建立在安全的基礎上。這正是趨勢科技致力透過執行零信任機制與創新人工智能原生威脅偵測來推動人工智能保安發展的原因。我們與 NVIDIA 的整合方案，將為高效人工智能部署建立全新的市場標準。」  
  
NVIDIA 高級傑出資訊保安架構師Ofir Arkin 表示：「隨著企業建置人工智能工廠，他們必須在不犧牲創新的前提下，保護大型且高速運作的基礎架構。透過與 NVIDIA BlueField 的整合，**Trend Vision One** 建立了一個全新的人工智能工廠端點偵測與回應類別，結合硬件層級的隔離與即時威脅洞察，從數據中心層面守護關鍵的人工智能資產。」  
  
根據 **Gartner**® 報告指出：「人工智能基礎架構安全包含底層科技組合中內建的資訊保安功能，例如向量與圖形資料庫，以及可由現有廠商擴展以涵蓋人工智能保安應用案例的第三方安全控制。」<sup>註一</sup>  
  
在此基礎上，趨勢科技也將防護擴展至代理式人工智能**的應用層面**。  
**Trend Vision One™ AI Application Security****（****AI Guard****）** 原生整合 NVIDIA NeMo Guardrails（NVIDIA NeMo **框架**的一部分），提供可擴展的防護欄協調方案，用以確保與大型語言模型互動的安全性、可靠性、準確性與主題相關性。這整合簡化了團隊定義、測試與協調人工智能防護欄的流程，並可透過微服務與簡易應用程式介面部署多模態防護欄。藉此，資訊保安團隊能將防護欄對應企業政策，並配對至主要風險，如提示注入、資料外洩、工具或代理濫用、越獄與幻覺生成等，並從開發到運作期執行一致性的防護。  
  
該平台能收集防護欄遙測數據來提昇觀測性、風險評分與事件回應，並在整個人工智能技術組合與雲端環境執行自動化政策即代碼（Policy-as-Code）更新及程序手冊驅動修復（Playbook-driven Remediation）。此整合式防護能偵測認證外洩、反向 Shell攻擊及其他進階威脅，同時在以下三大關鍵領域強化代理式人工智能的安全性：  
  
- **內容審核**：過濾惡意或具偏見的人工智能輸出，且不影響推論速度。
- **安全性**：以 NVIDIA BlueField 加速的硬體層隔離，防止提示注入與越獄攻擊。
- **私隱**：內建加密機制，符合 GDPR、HIPAA、CCPA 規範，並採用零信任分段架構。
  
  
註一：資料來源：Gartner，《Use an AI Security Platform to Launch Your AI Security Strategy》，作者 Dennis Xu、Kevin Schmidt、Jeremy D'Hoinne，2025 年 2 月 26 日。  
  
GARTNER 為 Gartner, Inc. 及其附屬機構在美國及其他地區的註冊商標及服務標誌，  
Magic Quadrant 為 Gartner, Inc. 及其附屬機構的註冊商標，經授權後在此使用。版權所有，翻印必究。  
  
  
  
![](https://release.media-outreach.com/Release/templates/images/socialMedia/iconmonstr-linkedin-1-24.png)https://www.linkedin.com/in/trend-micro-hong-kong-96353768/  
![](https://release.media-outreach.com/Release/templates/images/socialMedia/iconmonstr-twitter-1-24.png)https://twitter.com/trendmicroamea  
![](https://release.media-outreach.com/Release/templates/images/socialMedia/iconmonstr-facebook-1-24.png)https://www.facebook.com/tmhk1989/

發佈者對本公告的內容承擔全部責任

#### 關於趨勢科技

趨勢科技為網絡資訊保安方案全球領導廠商，致力建立一個讓人們、政府與企業安全交換資訊的世界。趨勢科技運用其深厚的安全專業知識與人工智能技術，保護全球超過 50 萬家企業及數百萬名個人用戶，涵蓋雲端、網絡、用戶端與各類裝置。核心產品 Trend Vision One™ 是唯一由人工智能驅動的企業級網絡保安平台，能夠集中網絡風險曝險管理與保安運作，並在駐場、混合雲及多重雲環境中提供多層次防護。趨勢科技所提供的卓越威脅情報，讓不同機構能夠主動防禦每日數以億計的網絡威脅。主動防護，由此啟廸。TrendMicro.com  

![](https://track.media-outreach.com/index.php/WebView/424531/18434)

# 資料來源
2025/11/05: [趨勢科技攜手 NVIDIA 推出針對代理式人工智能系統的端對端防護方 | 國際現場 | 商情 | 經濟日報](https://money.udn.com/money/story/12987/9119611) 