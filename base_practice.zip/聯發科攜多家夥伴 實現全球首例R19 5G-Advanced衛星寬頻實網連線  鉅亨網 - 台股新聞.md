---
新聞來源: "鉅亨網"
published: 2025-11-04
---
# 聯發科攜多家夥伴 實現全球首例R19 5G-Advanced衛星寬頻實網連線 | 鉅亨網 - 台股新聞
5G 晶片大廠聯發科 ([2454-TW](https://www.cnyes.com/twstock/2454)) 今 (4) 日宣布，與歐洲太空總署(European Space Agency)、Eutelsat、Airbus Defense and Space、SHARP、工業技術研究院、Rohde & Schwarz 攜手合作，成功運用 Eutelsat 的 OneWeb 低軌衛星完成了全球首次符合 3GPP R19 規範的 5G-Advanced 衛星寬頻實網連線成功。

![cover image of news article](https://cimg.cnyes.cool/prod/news/6217813/l/a39fe9906e64f05d25d8b1190ee24744.jpg)

聯發科攜多家夥伴 實現全球首例R19 5G-Advanced衛星寬頻實網連線。(擷取自官網)

無線通訊技術本部群資深本部總經理范明熙表示，作為地面與非地面通訊領域的領導者，無論是在行動網路覆蓋有限甚至缺乏的地區，公司持續以科技連結世界，致力改善人們生活。此次與生態系夥伴攜手合作，成功實現與 Eutelsat 低軌衛星實網連線，為 3GPP 為基礎的下世代 NR NTN 衛星寬頻通訊商用化又邁進一步。

聯發科指出，這將為 5G-Advanced NR NTN (非地面網路) 技術的商業部署奠定重要基礎，透過全球統一的 NTN 技術標準將不僅拓展衛星與行動通訊產業生態系的共通性以降低成本結構，並進一步推動全球 NTN 衛星寬頻裝置的普及與應用。

此次測試採用 OneWeb 低軌衛星與聯發科技 NR NTN 晶片組及工研院 NR NTN 基地台 (gNB) 進行通訊，實現包含 Ku 頻段、50MHz 頻寬、條件式切換 (conditional handover，CHO) 等 3GPP R19 規範所定義的新功能。

其中，由 Airbus 所打造的 OneWeb 低軌衛星搭載能接取 Ku 頻段服務鏈路 (service link) 與 Ka 頻段回傳鏈路 (Ka-band feeder link) 的透明轉發器 (transparent transponder)，並採用地球移動波束 (Earth-moving beams) 技術。

實網測試期間，搭載由 SHARP 開發之平板天線 (flat panel antenna) 的 NTN 終端裝置，成功透過設置於荷蘭的歐洲太空總署歐洲太空研究與技術中心 (European Space Research and Technology Centre) 的閘道天線完成與地面 5G 核心網路的連線。

隨著 3GPP 標準的全面整合並獲得整個行動通訊產業的廣泛採納，所有相容的衛星星系將能自然且無縫地補足地面網路的需求，實現真正無所不在並帶來規模經濟效益的通訊連接，並為智慧型手機、車用及物聯網等領域開啟全新市場。

# 資料來源
2025/11/4: [聯發科攜多家夥伴 實現全球首例R19 5G-Advanced衛星寬頻實網連線 | 鉅亨網 - 台股新聞](https://news.cnyes.com/news/id/6217813) 