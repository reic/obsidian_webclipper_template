---
新聞來源: "經濟日報"
published: 2025-10-30
---
# WEKA 宣佈推出為 NVIDIA BlueField-4 打造的全新 NeuralMesh 架構 | 全球企業動態 | 商情 | 經濟日報

革命性平台設計標誌著 AI 基礎設施的重大演進，消除傳統 CPU 需求，同時為企業級 AI 工廠提供突破性的效能密度、線性擴展能力和卓越的電源效率

華盛頓及加州坎貝爾2025年10月30日 /美通社/ -- 2025 年華盛頓 GTC 大會消息：[WEKA](https://edge.prnewswire.com/c/link/?t=0&l=zh-hant&o=4542842-1&h=4081698634&u=https%3A%2F%2Fedge.prnewswire.com%2Fc%2Flink%2F%3Ft%3D0%26l%3Den%26o%3D4542842-1%26h%3D1762317318%26u%3Dhttps%253A%252F%252Fwww.weka.io%252F%26a%3DWEKA&a=WEKA) 宣佈，正為 [NVIDIA 新發布的 BlueField-4 數據處理單元 (DPU)](https://edge.prnewswire.com/c/link/?t=0&l=zh-hant&o=4542842-1&h=2612209360&u=https%3A%2F%2Fedge.prnewswire.com%2Fc%2Flink%2F%3Ft%3D0%26l%3Den%26o%3D4542842-1%26h%3D4269659262%26u%3Dhttps%253A%252F%252Fnvidianews.nvidia.com%252Fnews%252Fnvidia-bluefield-4-ai-factory%26a%3DNVIDIA%2BBlueField-4%2Bdata%2Bprocessing%2Bunit%2B\(DPU\)&a=NVIDIA+%E6%96%B0%E7%99%BC%E5%B8%83%E7%9A%84+BlueField-4+%E6%95%B8%E6%93%9A%E8%99%95%E7%90%86%E5%96%AE%E5%85%83+\(DPU\)) 開發下一代 WEKA® NeuralMesh™ 智能儲存系統，此舉標誌著 AI 基礎設施架構與部署方式的革命性轉變。這種突破性方法無需獨立的 CPU 伺服器，而是利用 [NVIDIA BlueField-4](https://edge.prnewswire.com/c/link/?t=0&l=zh-hant&o=4542842-1&h=1498618092&u=https%3A%2F%2Fedge.prnewswire.com%2Fc%2Flink%2F%3Ft%3D0%26l%3Den%26o%3D4542842-1%26h%3D1356681968%26u%3Dhttps%253A%252F%252Fwww.nvidia.com%252Fen-us%252Fnetworking%252Fproducts%252Fdata-processing-unit%252F%26a%3D%25C2%25A0NVIDIA%2BBlueField-4&a=NVIDIA+BlueField-4) 史無前例的 800 Gb/s 網絡頻寬和 6 倍的運算效能提升，提供了 WEKA 行政總裁 Liran Zvibel 譽為「未來 AI 數據基礎設施的完美基石」。

[![WEKA 宣佈推出為 NVIDIA BlueField-4 打造的全新 NeuralMesh 架構](https://mma.prnasia.com/media2/2806613/Weka_nvidia_AI_Factory.jpg?p=original "WEKA 宣佈推出為 NVIDIA BlueField-4 打造的全新 NeuralMesh 架構")](https://mma.prnasia.com/media2/2806613/Weka_nvidia_AI_Factory.jpg?p=original)  
WEKA 宣佈推出為 NVIDIA BlueField-4 打造的全新 NeuralMesh 架構

重新構想 AI 基礎設施架構  
新一代 WEKA [NeuralMesh](https://edge.prnewswire.com/c/link/?t=0&l=zh-hant&o=4542842-1&h=1975130843&u=https%3A%2F%2Fedge.prnewswire.com%2Fc%2Flink%2F%3Ft%3D0%26l%3Den%26o%3D4542842-1%26h%3D3706907351%26u%3Dhttps%253A%252F%252Fwww.weka.io%252Fproduct%252Fhow-it-works%252F%26a%3DNeuralMesh&a=NeuralMesh) 儲存軟件將不再部署於帶有獨立 CPU 的傳統伺服器上，而是直接運行於 NVIDIA BlueField-4，從根本上簡化 AI 基礎設施的部署，同時顯著提升經濟效益、效能和電源效率。這一架構轉變代表了 WEKA 迄今為止與 NVIDIA 基礎設施路線圖及 AI 數據中心願景的最重要契合。

現代 AI 基礎設施的完美配搭  
NVIDIA BlueField-4 帶來了可編程基礎設施、加速功能、零信任安全以及強大的網絡能力，與 NeuralMesh 基於微服務的網狀架構無縫結合。當與 NVIDIA 最新的加速運算平台結合時，BlueField-4 和 NeuralMesh 為超大規模 AI 工廠建立統一、高效的基礎。

「AI 的急速發展需要能夠以前所未有的效率適應和擴展的智能數據基礎設施。」WEKA 聯合創辦人兼行政總裁 Liran Zvibel 表示，「WEKA 為 NVIDIA BlueField-4 打造的 NeuralMesh 架構是一次巨大的飛躍，為下一代 AI 工廠提供了基礎儲存。」

「AI 推理和其他推理工作負載的需求，需要一個全新的數據基礎設施基礎——此基礎能統一運算、網絡和儲存，以實現前所未有效率和規模。」NVIDIA 企業產品副總裁 Justin Boitano 表示，「透過與 NVIDIA BlueField-4 的整合，WEKA 的 NeuralMesh 儲存系統支持這一架構轉型，為超大規模 AI 工廠中高效的數據處理提供動力。」

BlueField-4 驅動架構的優勢  
基於 BlueField-4 的 WEKA 下一代 NeuralMesh 儲存系統將提供：

- 卓越的電源效率：為代理式 AI 工作流程帶來超過 100 倍的每瓦特詞元提升
- 簡化基礎架構：無需專用的獨立 CPU 儲存伺服器，降低複雜性並減少佔用空間。
- 更佳的經濟效益：整合運算、網絡和儲存功能，大幅降低基礎設施成本。
- 更強的效能：利用 BlueField-4 的 800 Gb/s 網絡和 6 倍運算效能提升，實現無與倫比的數據傳輸速度。
- 無縫整合：與 NVIDIA 的基礎設施路線圖和 AI 工廠架構保持一致。
- 零信任安全：透過 [NVIDIA DOCA™ 軟件框架](https://edge.prnewswire.com/c/link/?t=0&l=zh-hant&o=4542842-1&h=932882924&u=https%3A%2F%2Fedge.prnewswire.com%2Fc%2Flink%2F%3Ft%3D0%26l%3Den%26o%3D4542842-1%26h%3D865115384%26u%3Dhttps%253A%252F%252Fdeveloper.nvidia.com%252Fnetworking%252Fdoca%26a%3DNVIDIA%2BDOCA%25E2%2584%25A2%2Bsoftware%2Bframework&a=NVIDIA+DOCA%E2%84%A2+%E8%BB%9F%E4%BB%B6%E6%A1%86%E6%9E%B6)，內置安全加速功能並以線路速率實現租戶隔離。

為推理時代而設的協作  
WEKA 與 NVIDIA 已有近十年的緊密合作，範圍涵蓋 [NVIDIA AI Enterprise 軟件](https://edge.prnewswire.com/c/link/?t=0&l=zh-hant&o=4542842-1&h=897330714&u=https%3A%2F%2Fedge.prnewswire.com%2Fc%2Flink%2F%3Ft%3D0%26l%3Den%26o%3D4542842-1%26h%3D3028049819%26u%3Dhttps%253A%252F%252Fwww.nvidia.com%252Fen-us%252Fdata-center%252Fproducts%252Fai-enterprise%252F%26a%3DNVIDIA%2BAI%2BEnterprise%2Bsoftware&a=NVIDIA+AI+Enterprise+%E8%BB%9F%E4%BB%B6)、WEKA 榮獲多項 NVIDIA 認證，以及在 NVIDIA 新技術發布上的協作。基於 BlueField-4 的 NeuralMesh 儲存軟件，代表了 WEKA 迄今為止與 NVIDIA 技術最深度的整合。

「電源效率是實現超大規模 AI 工廠上線的關鍵。」WEKA 策略總監 Nilesh Patel 表示，「NVIDIA BlueField-4 和 WEKA 的 NeuralMesh 儲存軟件將直接應對這一挑戰，在不影響效能、規模或營運簡易性的前提下，提供突破性的每瓦特詞元效率。我們視 NeuralMesh 與 BlueField-4 的整合為一個策略增長引擎，能為我們的客戶簡化並加速企業級 AI 工廠的部署。」

上市時間與後續步驟  
WEKA 正積極為 NVIDIA BlueField-4 開發下一代 NeuralMesh 軟件版本，詳細的路線圖資訊將於 2026 年初與客戶和合作夥伴分享。有意深入了解 WEKA NeuralMesh 架構的機構，可直接聯繫 WEKA 或瀏覽 [www.weka.io](https://edge.prnewswire.com/c/link/?t=0&l=zh-hant&o=4542842-1&h=915179602&u=https%3A%2F%2Fedge.prnewswire.com%2Fc%2Flink%2F%3Ft%3D0%26l%3Den%26o%3D4542842-1%26h%3D3470960545%26u%3Dhttp%253A%252F%252Fwww.weka.io%252F%26a%3Dwww.weka.io&a=www.weka.io)。 

關於 WEKA  
WEKA 憑藉其智能、適應性網狀儲存系統 WEKA® NeuralMesh™，正在變革機構建立、運行和擴展 AI 工作流程的方式。傳統的數據基礎設施會隨著工作負載擴展而變得更慢、更脆弱，與此不同，NeuralMesh 會隨著規模擴展而變得更快、更強、更高效，與 AI 環境同步動態增長，為企業級 AI 和代理式 AI 創新提供靈活的基礎。NeuralMesh 深受 30% 的《財富》50 強企業信賴，幫助領先企業、AI 雲端服務供應商和 AI 開發者優化其 GPU、加速擴展 AI 並降低創新成本。如欲了解更多，請瀏覽 [www.weka.io](https://edge.prnewswire.com/c/link/?t=0&l=zh-hant&o=4542842-1&h=1641067737&u=https%3A%2F%2Fedge.prnewswire.com%2Fc%2Flink%2F%3Ft%3D0%26l%3Den%26o%3D4542842-1%26h%3D2029350567%26u%3Dhttps%253A%252F%252Fwww.weka.io%252F%26a%3Dwww.weka.io&a=www.weka.io) 或追蹤我們的 [LinkedIn](https://edge.prnewswire.com/c/link/?t=0&l=zh-hant&o=4542842-1&h=2792494438&u=https%3A%2F%2Fedge.prnewswire.com%2Fc%2Flink%2F%3Ft%3D0%26l%3Den%26o%3D4542842-1%26h%3D2903707630%26u%3Dhttps%253A%252F%252Fwww.linkedin.com%252Fcompany%252Fweka-io%26a%3DLinkedIn&a=LinkedIn) 和 [X](https://edge.prnewswire.com/c/link/?t=0&l=zh-hant&o=4542842-1&h=4255314028&u=https%3A%2F%2Fedge.prnewswire.com%2Fc%2Flink%2F%3Ft%3D0%26l%3Den%26o%3D4542842-1%26h%3D2343026440%26u%3Dhttps%253A%252F%252Fx.com%252FWekaIO%26a%3DX&a=X)。

WEKA 和 W 標誌乃 WekaIO, Inc. 的註冊商標，而此處其他商品名稱可能是其各自擁有人的商標。 

[![WEKA：企業人工智能的基礎](https://mma.prnasia.com/media2/1796062/WEKA_v1_Logo_new.jpg?p=original "WEKA：企業人工智能的基礎")](https://mma.prnasia.com/media2/1796062/WEKA_v1_Logo_new.jpg?p=original)  
WEKA：企業人工智能的基礎

# 資料來源
2025/10/30: [WEKA 宣佈推出為 NVIDIA BlueField-4 打造的全新 NeuralMesh 架構 | 全球企業動態 | 商情 | 經濟日報](https://money.udn.com/money/story/123828/9105705) 