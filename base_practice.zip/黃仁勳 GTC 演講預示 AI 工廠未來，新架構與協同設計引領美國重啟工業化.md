---
新聞來源: "TechNews 科技新報"
published: 2025-10-29
---
# 黃仁勳 GTC 演講預示 AI 工廠未來，新架構與協同設計引領美國重啟工業化
輝達 (NVIDIA) 創辦人暨執行長黃仁勳在華盛頓特區舉行的 GTC 大會主題演講中，描繪了人工智慧 （AI） 作為下一個工業革命的願景，並將其比喻為美國繼太空時代黎明以來最大的能力考驗。他強調，我們正處於技術的前端，將以最快的速度前進。輝達發布了一系列革命性的新產品和合作夥伴關係，目的在為全球的科學家、工程師和夢想家打造 「AI工廠」。

### 計算模式革命開始加速計算與摩爾定律終結

黃仁勳回顧了美國歷史上的創新時代，從貝爾實驗室的電晶體誕生、IBM System/360 到蘋果公司的個人電腦。他指出，半導體產業的基礎-登納德縮放 （Dinard scaling） 已在大約十年前停止。由於物理定律的限制，電晶體的性能和功耗增長已大幅放緩，這意味著摩爾定律 (Moore’s law) 無法持續。

![](https://img.technews.tw/wp-content/uploads/2025/10/29064148/2025-OCT-GTC-23.png)

為了解決通用電腦無法解決的問題，輝達發明了一種新的運算模型 「加速運算」。輝達發明了 GPU 和 CUDA 程式設計模型，透過利用並行計算能力，將運算能力擴展到傳統 CPU 之外。而 CUDA 已是該公司的核心寶藏，歷經 30 年的發展，現已推出 CUDA 13，即將推出 CUDA 14，還有數億個 GPU 運行著完全兼容的 CUDA。甚至，加速計算需要重新設計演算法、創建新的函式庫，並重寫應用程式，輝達也已針對不同領域如計算曝光 （cuLitho）、數值優化 （cuOpt）、醫療成像 （Monai） 和基因組學 （Ariel） 等，開發了 350 多個 CUDA X 函式庫。

### 從工具到工作者轉變的 AI 工廠

黃仁勳指出，AI 的影響遠超聊天機器人。AI 已經徹底改變了整個運算堆疊，從傳統的手寫代碼轉變為機器學習，這是一種訓練數據密集的編程方式，運行在 GPU 上。他解釋，AI 的計算單元是 Token。Token 可以代表文字、圖像、影片、3D 結構，甚至化學物質、蛋白質和基因等。一旦資訊被 Token 化，AI 就能學習其語言和含義，進行翻譯和生成。

![](https://img.technews.tw/wp-content/uploads/2025/10/29064803/2025-OCT-GTC-21.png)

過去，軟體產業是關於創建如 Excel 或瀏覽器這樣的工具。然而，AI 的本質是工作，AI 系統本質上是能夠使用這些工具的工作者。這種新的計算需求，需要一種新型的系統— AI 工廠。與過去用於儲存檔案和運行多種應用的通用資料中心不同，AI 工廠專門設計用於生產 Token，這些 Token 必須盡可能有價值，並且必須以極高的速率生產，同時具備成本效益。

### AI 發展正面臨兩個指數級成長壓力

黃仁勳強調，AI的發展現正面臨兩個指數級成長壓力。首先，隨著 AI 模型從預訓練、後訓練到推論，運算需求呈指數級增長。其次，由於 AI 模型變得更加智慧，人們願意為之付費，這形成了一個良性循環。模型越智能，使用的人越多。使用越多，所需的計算資源就越多。

![](https://img.technews.tw/wp-content/uploads/2025/10/29064224/2025-OCT-GTC-10.png)

為維持這個良性循環，並在摩爾定律結束之際大幅降低成本，輝達採用了極致協同設計（Extreme Co-Design）。這種設計從零開始，同時考慮新的電腦架構、晶片、系統、軟體、模型架構和應用程式。透過這種方法，輝達推出了 Blackwell 架構及 Grace Blackwell NVLink 72 系統。GB200 是第一個機架級 AI 超級電腦，而下一代則是 Vera Rubin。

黃仁勳展示了 Vera Rubin 系統的設計，該系統將整個機架視為一台電腦，透過 NVLink 72 將 72 個 GPU （或144個GPU核心） 連接成一個巨大的虛擬 GPU。整體 Grace Blackwell NVLink 72 的性能提升是驚人的。Grace Blackwell 每個 GPU 的性能比 H200 高出 10 倍。儘管 GB200 是最昂貴的電腦之一，但其 Token 生成能力極強，能以全球最低的成本生產 Token。 這證明了極致協同設計的效益：性能提高 10 倍，成本降低 10 倍。

![](https://img.technews.tw/wp-content/uploads/2025/10/29064249/2025-OCT-GTC-6.png)

輝達預計 Blackwell 和 Rubin 架構將帶來巨大的市場成長。到 2026 年，Blackwell 和 Rubin早期的累積業務可見度已達五千億美元，這是 Hopper 整個生命週期增長率的五倍。此外， NVIDIA 強調了將製造業帶回美國的承諾，Blackwell 和未來幾代 AI 工廠系統將在亞利桑那州、印第安納州和德克薩斯州等地製造。

### 六大領域的創新突破與合作夥伴

在演講中，黃仁勳指輝達為了發展整個 AI 生態系，宣布了在六個關鍵領域的重大進展：

1\. 6G 與電信基礎設施：為了讓美國在 6G 革命中再次居於核心地位，輝達與諾基亞 （Nokia） 達成重大合作。輝達推出了新的產品線 「NVIDIA Arc」（空中無線電網路電腦，Aerial Radio Network Computer）。「NVIDIA Arc」 結合了 Grace CPU、Blackwell GPU 和 C onnectX 網路，運行 Aerial 函式庫。諾基亞將採用 「NVIDIA Arc」 作為其未來基地台，並能升級全球數百萬個 Airscale 基地台，實現 6G 和 AI 功能。

![](https://img.technews.tw/wp-content/uploads/2025/10/29064338/2025-OCT-GTC-24.png)

2.量子計算：量子計算的未來是 GPU 超算與量子處理器 （QPU） 的協同工作。為此，輝達發布了 NVQLink，這是一種新的互連架構，能夠直接連接量子處理器和 NVIDIA GPU。 NVQLink 能夠以每秒數千次的速度傳輸 TB 級數據，以進行量子錯誤修正 （Quantum Error Correction） 和 AI 校準。目前，平台已得到 17 家量子計算公司和幾乎所有美國能源部 （DOE） 實驗室的支持。

3.企業運算與網路安全：AI 將極大地提升網路安全挑戰，需要更強大的防禦者。輝達與 CrowdStrike 合作，創建雲端和邊緣的網路安全 AI 代理。此外，輝達還與 Palantir 合作，加速其 Ontology 平台，以便能夠以光速處理結構化和非結構化數據，用於國家安全和企業洞察。

4.機器人與實體 AI（Physical AI）：實體 AI 需要三種電腦，那就是用於訓練模型的 Grace Blackwell、用於模擬 （數位分身） 的 Omniverse 電腦，以及用於操作的 Jetson Thor 機器人電腦。輝達推出了 Omniverse DSX，作為建造和操作 Gigascale AI 工廠的藍圖。DSX 實現了計算、電力和冷卻設施的協同設計。輝達正與鴻海 Figure、Agility 和 Disney Research 合作，推出可愛的機器人 Disney Blue，其動作完全在 Omniverse 中模擬學習。

![](https://img.technews.tw/wp-content/uploads/2025/10/29064410/2025-OCT-GTC-16.png)

5.自動駕駛：機器人正在輪子上實現商業化。輝達發布了 Drive Hyperion 平台，這是一個標準化的傳感器套件和計算平台，目的在讓全球汽車公司，如 Lucid、Mercedes-Benz、Stalantis 等能夠開發 Robo Taxi。輝達還宣布與 Uber 合作，將 Drive Hyperion 汽車連接到全球網路。

6.開源模型：黃仁勳強調，美國必須引領開源模型 （Open-Source Models） 的發展，因為這是科學家、研究人員和新創公司的命脈。輝達一直以來在開源貢獻方面處於領先地位，在各大排行榜上擁有 23 個模型，涵蓋語言模型、實體 AI 模型到生物學模型。

![](https://img.technews.tw/wp-content/uploads/2025/10/29064436/2025-OCT-GTC-13.png)

黃仁勳最後總結，我們正經歷著兩次平台轉型，從通用計算到加速計算，以及從傳統手寫軟體到 AI。而輝達正在為 6G（ARC）、機器人汽車 （Hyperion） 和 AI 工廠 （DSX） 打造新的平台，並將製造業帶回美國。

(首圖來源：視訊截圖)

# 資料來源
2025/10/29: [黃仁勳 GTC 演講預示 AI 工廠未來，新架構與協同設計引領美國重啟工業化](https://finance.technews.tw/2025/10/29/jensen-huangs-gtc-speech-foreshadows-the-future-of-ai-factories/) 