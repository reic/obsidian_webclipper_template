---
新聞來源: "鉅亨網"
published: 2025-11-02
---
# AI推論需求爆發 慧榮估2026年DRAM、NAND全面短缺 | 鉅亨網 - 台股新聞
記憶體控制晶片大廠慧榮 ([SIMO-US](https://invest.cnyes.com/usstock/detail/SIMO)) 總經理苟嘉章指出，AI 推論需求爆發，帶動全球記憶體市場進入「結構性缺貨」階段，預估 2026 年 DRAM 與 NAND Flash 都將呈現全年性短缺。

![cover image of news article](https://cimg.cnyes.cool/prod/news/6214431/l/04ebb6d6202b91ca3382bb735516e5d6.jpg)

慧榮總經理苟嘉章。(業者提供)

苟嘉章表示，微軟 ([MSFT-US](https://invest.cnyes.com/usstock/detail/MSFT))、谷歌 ([GOOG-US](https://invest.cnyes.com/usstock/detail/GOOG))、亞馬遜 ([AMZN-US](https://invest.cnyes.com/usstock/detail/AMZN)) 與 Meta 等雲端服務供應商 (CSP) 紛紛投入 AI 推論領域，帶動高頻寬記憶體 (HBM) 需求急速成長，且由於供應商將產能轉向 HBM 製造，使傳統 DDR4 產能被排擠，市場供不應求。

他預估，DRAM 市場在 2026 年將缺貨一整年，不過隨著三星 (Samsung)、SK 海力士與美光 ([MU-US](https://invest.cnyes.com/usstock/detail/MU)) 新廠陸續投產，2027 年有望出現緩解跡象。

在 NAND Flash 方面，苟嘉章指出，2026 年市場同樣將缺貨，除了韓系與日系大廠三星、SK 海力士與鎧俠 (Kioxia) 外，中國長江存儲在內需支撐下，有望於三年內擠進全球前四大供應商行列，全球市場版圖勢將出現明顯變化。

他強調，這波缺貨潮並非供應端縮減產能造成，而是 AI 推論與高階手機需求帶動的「結構性缺貨」，雖然市場上不乏重複下單現象，但實際需求強勁，整體供需失衡短期仍難解。

苟嘉章也提到，目前傳統硬碟 (HDD) 供應鏈高度集中，僅 2 至 3 家供應商，且擴產態度相當保守，導致交期長達一年甚至更久，也提升客戶改採 NAND 的意願，並看好 AI 推論帶來的記憶體熱潮將延續多年，希望全球供應鏈能穩健擴產、維持健康發展，避免再次陷入景氣循環的極端波動。

# 資料來源
2025/11/2: [AI推論需求爆發 慧榮估2026年DRAM、NAND全面短缺 | 鉅亨網 - 台股新聞](https://news.cnyes.com/news/id/6214431) 