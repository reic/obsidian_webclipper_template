---
新聞來源:
published:
---
# iT 邦幫忙::一起幫忙解決難題，拯救 IT 人的一天
## 前言

從這篇文章開始，我們要進入到 Obsidian 的操作了。在正式開始教學之前，我先快速簡介 Obsidian 的優勢與劣勢。

### Obsidian 的優勢

Obsidian 目前是網路上成長最快的筆記管理軟體之一 ，由於其程式開放的特性，讓許多程式開發者能藉由 Obsidian 官方 API 打造非常多的創新應用，大幅提升 Obsidian 的軟體功能。

此時 Obsidian 的社群人數已多達上萬人，每一天都會在官方的 [Obsidian forum](https://forum.obsidian.md/) 和 [Obsidian discord](https://obsidian.md/community "Obsidian Discord") 討論與分享個人的筆記方式。對於喜歡學習、喜歡整理專業知識的人來說， 參與討論與自己實作都會學到非常多東西。

### Obsidian 的劣勢

Obsidian 的功能雖然強大，但使用上有一定的學習門檻。對一個初學者來說，會發現 Obsidian 跟 Evernote、Notion 的使用方式大不相同，因此容易放棄使用。

我認為在使用進階功能之前，最好先熟悉 Obsidian 的基礎操作，再逐步增加新的插件，這樣才不會讓自己迷失在軟體的複雜功能中。

了解 Obsidian 整套系統之後，你可以開始打造自己的 [知識架構](https://ithelp.ithome.com.tw/articles/10263698) ，甚至建立視覺化的知識網，幫助你更有效的組織專業領域的知識。

![打造屬於個人的知識圖譜](https://miro.medium.com/max/770/1*CVCrSMEYG_zDfprPxu8sYw.png)

讓我們先從基礎的操作方式開始學起，由簡單到困難，你絕對能逐漸掌握這套軟體的使用方式，並且發現其中的迷人之處。

這篇文章就先從「預設介面」與「基礎功能」開始學起吧！

---

## 一、下載與安裝 Obsidian

首先到 [官網](https://obsidian.md/) 下載 Obsidian 軟體。

![Obsidian 官方網站](https://cdn.jsdelivr.net/gh/vizance/image/20210905205145.png)

安裝步驟非常簡單，一直按「下一步」即可。安裝完畢後開啟 Obsidian，會看到下方的軟體介面。

### 開啟 Help Vault

畫面上的 Vault 代表的是「資料夾」的意思，Obsidian 會請創建一個資料夾當作預設開啟位置，你能夠編輯的檔案就是在該「資料夾」中。

請選擇 Open help vault 以利了解基礎操作功能; 另外 Obsidian 也支援多國語言，可選擇「繁體中文」方便使用。

`小建議：由於 Obsidian 的社群插件與討論多是英文，可以在一開始先選擇「繁體中文」，等熟悉後建議還是調回英文。`

![Open help vault](https://miro.medium.com/max/770/1*6w772uZAy5jjEKutbQ5eMg.png)

這邊特別說明： Obsidian 中編輯的每一個筆記檔案，實際上都是副檔案均為 `.md` 的 Markdown 檔案格式。這邊你可以把 `.md` 檔案當成是 `.doc` 的 Word 檔案，這樣可以幫助理解。

![每一則筆記都是 .md 檔案格式](https://miro.medium.com/max/770/1*6Bg-wYDxekNWrdJ1E9PwWw.png)

這代表著你擁有每一則筆記的所有權，就像是你擁有每一份 `.doc` Word 檔案，這是 Obsidian 跟 Evernote、Notion 筆記軟體最大的不同。(Evernote 跟 Notion 都需要額外匯出筆記，才能儲存到自己的本機端硬碟中 )

---

## 二、初探 Obsidian 介面

打開 help vault 後你會看到下方畫面。

![Obsidian 基礎面板](https://miro.medium.com/max/770/1*-MV2CeCeVW_ZYVH7qgwKeg.png)

看起來黑摸摸的一片，很像是工程師寫程式的介面…

放心，這些介面之後都是可以更改的，除了有官方主題、社群分享的主題，如果你會寫 CSS 甚至可以自己客製化。這屬於比較進階的主題，後面的文章會在介紹。

![我的 Obsidian 基礎面板](https://miro.medium.com/max/770/1*7-sQTlSTgSej3LWRcoytHg.png)

為了方便說明，我都會以官方預設的主題做講解，跟你在自己電腦上看到的內容是完全一樣的。

---

## 三、認識預設介面

在 Obsidian 中總共有 4 大功能區域：

1. 快捷功能列
2. 檔案管理區
3. 編輯面板
4. 連結面板

以下將介紹每個區域的主要功能。  
![](https://miro.medium.com/max/2000/1*HJViaFEWbDcbixkgFKo5YQ.png)

### 1\. 快捷功能列

![如果圖標看不清楚，請對照自己的 Obsidian 介面](https://miro.medium.com/max/2000/1*nOKS61XQh_85wT9Pg2bVlQ.png)

**1.快速切換筆記**

點擊後可快速搜尋、切換筆記。

![快速切換筆記：這項功能在後續會不斷的被使用到](https://miro.medium.com/max/1400/1*mKxNUU25NINMi-93Yd10vQ.png)

快速切換筆記：這項功能在後續會不斷的被使用到

**2.關聯圖**

開啟筆記之間的關聯圖，是 Obsidian 的軟體賣點之一。

透過關聯圖，可以看到每則筆記之間的連結關係，也可以對節點做顏色的客製化。在後面的文章會講到許多應用。

![筆記之間的關聯圖](https://miro.medium.com/max/60/1*ebMFIzS2sroOsnNzUwO3dA.png?q=20)

**3.開啟命令面板**

開啟 Obsidian 的命令面板，由於命令很多就不在此一一介紹。這項功能要搭配不同的使用情境介紹比較有意義，可以先不用特別理會。

![開啟命令面板](https://miro.medium.com/max/770/1*gorcBuPwVQ0FcJABr4HS-Q.png)

**4.開啟 Markdown 格式轉換器**

如果你正在使用 Roam Research、Bear 或是 Zettelkasten 檔案命名方式，可透過此功能轉換成 Obsidian 能辨識的格式。但我想多數人應該都不太會使用到這個功能。

![Markdown format importer](https://miro.medium.com/max/770/1*p_9GMXr77Y0NgzXd5Jq3eA.png)

**5.開啟其他儲存庫 (Vault)**

如同前面說的，Obsidian 是以「 資料夾」的概念編輯筆記，因此你可以選擇不同資料夾來編輯。

![Open another vault](https://miro.medium.com/max/770/1*doFs6UTeBlbodl1nxnygaQ.png)

那麼選擇不同的資料夾編輯有什麼意義嗎？

最大的影響在「瀏覽檔案的複雜度」。當你的筆記檔案愈來愈多的時候，如果開啟的資料夾中包含非常多的子資料夾，可能導致左側的資料夾非常多很難瀏覽。

以我個人的使用經驗，其實當筆記少的時候開啟哪個資料夾的差別不大，我建議先開啟包含最多檔案的母資料夾即可。(如下圖左側)

![Open another valut](https://miro.medium.com/max/770/1*TYF5aYaCor72YYK8_bBNCg.png)

**6.說明**

可開啟 Help Vault (即你現在看到的這份 Obsidian 預設教學檔案)。當你熟悉了使用方式，就可以移除 Help Vault 了。

再次點擊「說明」時，系統會再次產出這份教學檔案。

**7.設定**

更多設定選項，將在之後的文章說明。

![Setting](https://miro.medium.com/max/770/1*KnG0MHtgmzmjeyMHraodUw.png)

### 2\. 檔案管理區

資料夾與檔案顯示處，可使用拖拉的方式移動檔案。

上方的 3 個功能分別代表：

- 新建筆記
- 新建資料夾
- 改變排列方式

![](https://miro.medium.com/max/2000/1*SmRCXfPiLwA5TT97hel_hQ.png)

如果對檔案按下「右鍵」，會出現其他功能選項。需要特別說明的是下者 (編輯面板)：

![編輯面板](https://miro.medium.com/max/1400/1*YC4TnHhNomJzchB0_J1cqg.png)

### 3\. 編輯面板

Obsidian 中主要編輯筆記的地方，功能比較多一些。

![編輯面板](https://miro.medium.com/max/2000/1*r_hqqaPxCZ4g7MvUZYQeXQ.png)

**(1) 連結面板**

在 Obsidian 中可以同時開啟多個面板 (編輯區域)，如果我們想要讓兩個面板「連動」時，就可以使用此功能。

例如我開啟了兩個面板 (一個是編輯面板、一個是預覽面板)，透過連結面板我可以移動其中一個面板時，讓另外一個面板一起移動。

![沒有連結面板時](https://cdn-images-1.medium.com/max/880/1*JN0JhPliEPLyDS6TuRyXWA.gif)

![有連結面板時](https://miro.medium.com/max/1400/1*LCkntKeZpIs0cacYZj-g5Q.gif)

**(2) 釘選**

固定住某一筆記頁面，但我很少會使用。

**(3) 垂直分割**

將筆記畫面垂直分割，可分割多數個筆記畫面互相參照。

分割後的畫面可自由移動，只要你的螢幕夠大就可以切成無數個畫面。

![切割成 6 個筆記畫面，可同時開啟多數個筆記檔案](https://cdn-images-1.medium.com/max/880/1*FKA0mUXDqZWYhq2qUqpjtg.png)

**(4) 水平分割**

將筆記畫面水平分割，可分割多數個筆記畫面互相參照。

![水平分割](https://cdn-images-1.medium.com/max/880/1*orrFWpX2HK9as8Ck3h-dTg.png)

**(5) 刪除檔案**

將筆記檔案直接丟到電腦的「垃圾桶」。

**(6) 複製 Obsidian 網址**

複製這篇 Obsidian 筆記的連結，未來點擊此連結時，會直接開始連結。

**(7) 在檔案管理區顯示筆記**

點擊後會在左側的「檔案管理區」顯示此則筆記的位置。

![凸顯位置](https://cdn-images-1.medium.com/max/880/1*Q_9Ob-LBSJs8ZCurRx3waQ.png)

**(8) 搬移檔案到**

將這則筆記移動到某個資料夾中。

![搬移檔案](https://cdn-images-1.medium.com/max/880/1*MKRR9SDULrHdl5A2b6d82A.png)

**(9)開啟當前筆記關聯圖**

前面提到的 Open Graph View 是開啟整個資料夾的關聯圖，但此功能只開啟跟這則筆記有關的關聯圖。

此功能非常實用，可以看目前的筆記跟其他哪些筆記有關聯。

![當前筆記關聯圖](https://cdn-images-1.medium.com/max/880/1*UC7AxAdaG-VebK316QyyRA.png)

**(10) 開啟反向連結**

Obsidian 的殺手級功能，能看出：

- Linked mentions (已連結筆記的檔案)
- Unlinked mentions(未連結但提及本筆記的檔案)

在「4.連結面板」會再詳細解說。

**(11) 使用預設應用開啟**

可使用其他軟體開啟 Markdown 檔案，很少使用。

**(12) 在檔案總管中顯示**

顯示此則筆記在電腦資料夾的位置。

![在資料夾中顯示筆記檔案位置](https://cdn-images-1.medium.com/max/880/1*DuWFwm49DtA4M_E0hWTBtQ.png)

在資料夾中顯示筆記檔案位置

**(13) 查詢**

查詢筆記中的關鍵字。

**(14) 取代**

可單個或多個取代特定的文字，例如下方是將「note」取代成「筆記」。

![取代](https://cdn-images-1.medium.com/max/880/1*kyynw4g0KSKyEnADNZA96g.png)

**(15) 匯出 PDF**

將筆記匯出成 PDF 檔案。

### 4\. 連結面板

Obsidian 的殺手級功能 — 反向連結 (backlinks)，可顯示以下兩大資訊。

- **Linked mentions (已連結筆記的檔案)：此則筆記被哪些筆記連結**

![反向連結](https://cdn-images-1.medium.com/max/880/1*k5_-NFY3jS2U6aDXPPWTWQ.png)

這項功能的強大之處，在於其他則筆記中若有使用 `[[筆記名稱]]` 進行連結，就會在 Linked mentions 中顯示。

在 Obsidian 中我們會不斷的使用 `[[筆記名稱]]` 這個語法，他的功能是將這個概念連結到另外一則相關的筆記上。

例如我在「Obsidian Plugin (插件)」這則筆記中，有一些概念是跟「Publish (發表)」有關，因此我將在「Obsidian Plugin (插件)」筆記中的 Publish 連結到「Publish (發表)」這則筆記。如此一來，在關聯圖上就可以看到這兩則筆記產生「連結」了。

![關聯圖上的連結](https://cdn-images-1.medium.com/max/880/1*yGGXaRKStrQoNOPUB0ZLsQ.png)

後續我會提到如何有技巧的使用這項功能，幫助我們建立屬於自己的知識體系。

- **Unlinked mentions(未連結但提及本筆記的檔案)**

上方的 Linked mentions 是透過我們「主動」連結筆記。但有時候我可能會忘記「Obsidian Plugin (插件)」這則筆記中有一些概念是跟「Publish (發表)」有關。

Obsidian 會自動的幫助我們進行比對，如果「Obsidian Plugin」這則筆記中有提到 Publish 這個字，就會在「Publish」這則筆記的 Unlinked mentions 中出現，讓我們自行做連結。

![](https://cdn-images-1.medium.com/max/880/1*1ZFbTQeM3e_S_kviOACx4Q.png)

值得一提的是，「Obsidian Plugin」筆記的 Publish 必須跟「Publish」是完全相符的 (不限大小寫)，Obsidian 才能辨識到。

因此如果有一則筆記叫做「Publish Website」，而「Obsidian Plugin」筆記中只有寫到 Publish，那麼在「Publish Website」的 Unlinked mentions 是不會出現「Obsidian Plugin」這則筆記的。

你可能會很好奇：這樣我怎麼能保證筆記的命名，一定會被其他則筆記提到呢？

要解決這個問題，在 Obsidian 在 [V.0.9.17](https://twitter.com/obsdmd/status/1332118622240694274) 推出了 `aliases(別名)` 的功能，可以讓我們對同一則筆記，同時取不同的名稱。例如你可以為 Publish Website 取個別名叫做 `Publish` ，這樣就能夠被搜尋到了。

關於筆記的命名方式我之後文章也會提到，到時再詳細說明。

---

## 四、總結

這篇文章帶大家了解了 Obsidian 的基礎功能當作暖身，後續的文章會再說明比較常使用的功能以及設定。

Obsidian 的功能看起來非常多，但不是每個功能都需要的。先學會基礎的操作以及 `[[文章名稱]]` 連結功能，Obsidian 其實就已經學會了 60% 了。[此系列  
上一篇](https://ithelp.ithome.com.tw/m/articles/10265859)[此系列  
下一篇](https://ithelp.ithome.com.tw/m/articles/10266804)

# 資料來源
: [iT 邦幫忙::一起幫忙解決難題，拯救 IT 人的一天](https://ithelp.ithome.com.tw/m/articles/10266794) 