---
新聞來源: "經濟日報"
published: 2025-11-05
---
# SK海力士加深與台積合作 攜手晶圓一哥研發新型 HBM 基礎裸晶 | 產業熱點 | 產業 | 經濟日報
![SK海力士。路透](https://pgw.udn.com.tw/gw/photo.php?u=https://uc.udn.com.tw/photo/2025/11/04/realtime/33569263.jpg&x=0&y=0&sw=0&sh=0&exp=3600&w=441)

SK海力士。路透
AI記憶體龍頭SK海力士揭露其新世代記憶體技術藍圖，目標要跨過AI世代「記憶體高牆」的障礙，並透露正與台積電[（2330）](https://money.udn.com/industry/company/2330)密切合作下一代高頻寬記憶體（HBM）基礎裸晶（base dies），目標成為「全線AI記憶體創造者」。

SK海力士在AI用的HBM洞燭機先，超越三星，成為業界霸主。SK海力士強調，記憶體不再只是一個普通元件，而是正在演變成AI產業中的核心價值產品。

![](https://pgw.udn.com.tw/gw/photo.php?u=https://uc.udn.com.tw/photo/2025/11/05/2/33573381.png&x=0&y=0&sw=0&sh=0&sl=W&fw=1050&exp=3600&exp=3600)

SK海力士認為，儘管AI的採用正在加速中，導致資訊流量爆炸性成長，但支援這些成長的硬體技術，尤其是記憶體性能，未能與處理器的進步保持同步，形成所謂「記憶體高牆」的障礙。

SK海力士指出，集團一直扮演「全線記憶體供應商」角色，專注於及時提供符合客戶需求的產品，然而，隨著記憶體重要性增加，單純的「供應商」角色已不足以滿足市場需求，因此，集團新的目標是成為「全線AI記憶體創造者」。

SK海力士揭露其新世代記憶體技術藍圖，包括客製化HBM（Custom HBM）、AI DRAM（AI-D）和AI NAND（AI-N）等三大方針。

SK海力士並針對AI DRAM（AI-D）細分為三大類，首先是AI-D O（Optimization）優化，主打低功耗、高性能DRAM，目的在降低總體擁有成本並提高營運效率。其次是AI-D B（Breakthrough）的突破，為克服「記憶體高牆」的解決方案產品，其特點是超高容量記憶體和靈活的記憶體分配。第三為 AI-D E（Expansion）的擴展，目的為擴展DRAM的使用案例，不僅限於資料中心，還擴展至機器人、移動性和工業自動化等領域，該解決方案包含HBM。

AI NAND（AI-N）方面， SK海力士也正準備三種下一代儲存解決方案，包括AI-N P（Performance）提高性能、 AI-N B（Bandwidth）加大頻寬、AI-N D（Density）發展密度。

SK海力士並透露，正與台積電密切合作下一代HBM基礎裸晶。業界指出，SK海力士特別提到台積電，意味台積電在AI時代扮演的角色日益重要。

SK海力士是台積電於2022年成立的「3D Fabric聯盟」的成員之一，雙方積極加強合作。SK海力士去年與台積電簽合作備忘錄，攜手進行HBM4研發。

  
**延伸閱讀**

[SK海力士儲存方案革新 群聯搶商機](https://money.udn.com/money/story/5612/9117852?from=edn_editorrelated_story)

[南亞科傳大幅調薪 碩士畢業生月薪直逼護國神山](https://money.udn.com/money/story/5612/9117863?from=edn_editorrelated_story)

# 資料來源
2025/11/05: [SK海力士加深與台積合作 攜手晶圓一哥研發新型 HBM 基礎裸晶 | 產業熱點 | 產業 | 經濟日報](https://money.udn.com/money/story/5612/9117846) 