---
新聞來源: "數位時代 BusinessNext"
published: 2025-10-27
---
# Obsidian教學｜Obsidian是什麼？跟Notion差在哪？如何用它生成「知識網路」筆記？
你有過這種感覺嗎？每天都接觸非常多的碎片化知識，卻常常感到它們像散開的拼圖，難以串聯成完整的知識網路，感覺無法融會貫通。



這篇文章要介紹的筆記軟體Obsidian或許能夠幫你解決這個困擾！Obsidian主要採用類似大腦神經元的連結方式，讓筆記之間形成一個知識網絡。這種連結方式更有利於使用者學習或是激發創造力。



《數位時代》以下針對Obsidian新手整理基本的使用方法，一起來看看這款筆記軟體怎麼使用吧！





掌握最新AI、半導體、數位趨勢！訂閱《數位時代》日報及社群活動訊息







謝謝訂閱😊  
祝你有美好的一天





      

 



  

 









請稍等



 ![](https://www.bnext.com.tw/%22https://cdn.bnextmedia.com.tw/assets/bnextmedia/circled-right.gif/%22)













## Obsidian是免費的嗎？



Obsidian可以免費使用，筆記資料完全由用戶掌控，無需註冊或登入。不過，若是用戶想使用同步（Sync）和發布（Publish）功能，或是端對端加密等增值服務，則需要額外付費。







    ![\"Obsidian價格\"](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/39rp-1761550072.png?w=600&output=webp\%22)  



 



圖／ Obsidian











## Obsidian下載與安裝



Obsidian不提供網頁版，因此需要下載桌面程式，或是在行動App上使用，本篇文章教學以桌面版為主。



> 
> 
> [Obsidian下載傳送門](https://www.bnext.com.tw/%22https://obsidian.md/download/%22)
> 
> 



Obsidian預設語言為英文，最下方會顯示語言設定，點擊下拉選單找到繁體中文即可更換語言。



更換語言後，點擊「建立」，Obdisian會要求使用者建立一個儲存庫，輸入儲存庫名稱後，需要在電腦上選擇一個儲存庫的位置，作為備份使用。



 ➜ [新創強、卻不上市？簡立峰點名「小金雞」被動釋股與集團管理心態，正是拖慢臺灣資本動能的結構性問題 ](https://www.bnext.com.tw/%22https://bnex.tw/8blzmk/%22 "\\"新創強、卻不上市？簡立峰點名「小金雞」被動釋股與集團管理心態，正是拖慢臺灣資本動能的結構性問題\\"") 







    ![\"Obsidian安裝\"](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/jevk-1761550172.jpg?w=600&output=webp\%22)  



 



圖／ Obsidian











此舉除了備份，另一原因是在Obsidian建立的筆記，都會在電腦上被儲存為「md」格式的檔案，只需要使用純文字軟體便可打開。這樣即便日後不再使用Obsidian了，使用者也能直接將筆記帶走，避免出現被「綁死」在一個筆記軟體上的情形。







    ![\"Obsidian備份\"](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/gxzp-1761550274.png?w=600&output=webp\%22)  





在Obsidian建立的筆記，都會在電腦上被儲存為「md」格式的檔案，只需要使用純文字軟體便可打開。

 



圖／ 數位時代











## Obsidian介面認識



Obsidian的介面可以分成4個部分，正中間的空白頁就是筆記編輯區，可以在此做撰寫，建立連結，匯入圖片等動作。



左側的工具面板從左到右，依照圖示分別為：新增筆記、新增資料夾、排序、自動揭示目前檔案、全部展開。所有新增的筆記也會展示在左側的工具面板中，方便使用者隨時調用。



最左側工具列，從上至下，依序為：  
- 開啟快速切換（放大鏡圖示）：快速搜尋並開啟筆記或執行命令。  
- 查看關聯圖：以視覺化方式呈現筆記間的連結關係。  
- 建立新畫布：開啟一個自由排版的視覺工作區。  
- 開啟今天的每日筆記：快速建立或開啟當天的日誌筆記。  
- 插入模板：使用預設模板快速建立筆記內容。  
- 開啟命令面板：執行各種Obsidian內建或外掛功能。  
- 開啟新的base：建立新的筆記儲存庫。



右側的工具面板，則是用於查看筆記中所建立的各種連結，以及筆記中的標籤。







    ![\"Obsidian介面\"](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/bk9r-1761550697.jpg?w=600&output=webp\%22)  



 



圖／ Obsidian











## Obsidian教學1：筆記怎麼建立？



要建立筆記，只需點擊畫面中的「建立新檔案」，即可開始撰寫筆記。



Obsidian與市面上大多筆記軟體相似，支援Markdown語法的輸入。Markdown是一種輕量級標記語言，讓使用者可以用易讀易寫的純文字格式來編寫文件，以便能在其他文字編輯器中開啟和編輯。



在右上方的選單，可選擇筆記的編輯模式。Obsidian主要提供兩種模式：


- 即時預覽：這是Obsidian的預設模式可以在輸入Markdown語法的同時，看到渲染後的筆記最終畫面，無需手動切換。
- 原始碼模式：如果只想看到純粹的Markdown語法，可以切換到此模式。



若想在輸入筆記的同時，在旁邊預覽另一份筆記，可點擊右上方的選單，選擇「向右分割」，即可開啟一個並排的畫面。







    ![\"Obsidian分割頁面\"](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/n8sr-1761550816.png?w=600&output=webp\%22)  





點擊右上方的選單，選擇「向右分割」

 



圖／ Obsidian















    ![\"Obsidian分割頁面\"](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/fwjh-1761550864.png?w=600&output=webp\%22)  





出現並排頁面，可同時查看Markdwon語法與顯示效果

 



圖／ Obsidian











### 常見的Markdown語法

                

| 格式 | 輸入語法 |
| --- | --- |
| **標題** | `# 標題一` `## 標題二` `### 標題三` |
| **粗體** | `**粗體文字**` |
| **斜體** | `*斜體文字*` |
| **列點** | `- 重點一 - 重點二` |
| **編號列表** | `1. 項目一 2. 項目二` |
| **引用** | `> 這是引用的文字。` |
| **連結** | `[連結文字](https://www.example.com)` |



## Obsidian教學2：如何建立筆記資料夾？



使用筆記軟體時，最重要的就是為所有零散的筆記做分類，因此這裡我們需要認識Obsdian的「建立資料夾」功能。



譬如，我們想要研究一個名為「處理器」的主題，並為此寫了3篇名為NPU、CPU、GPU的筆記，想要分類筆記，可以這樣做：


1. 點擊左側工具面板的第二個圖示，或是右鍵即可喚出建立新資料夾選項。
2. 為資料夾命名（例如：「處理器」）。
3. 將主題相關的筆記（如：NPU、CPU、GPU）拖入該資料夾中，這樣就能將相同主題的筆記集中管理。







    ![\"Obsidian資料夾\"](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/26rj-1761550982.png?w=600&output=webp\%22)  





在Obsidian左側工具欄點擊第二個圖示，即可新增資料夾，並對筆記進行管理

 



圖／ Obsidian











## Obsidian 教學 3：如何分類主題



除了建立資料夾外，Obsidian也提供類似蘋果記事本裡用標籤分類筆記的方式，只需要在筆記中輸入「#」即可建立標籤。譬如，我們為「NPU」這個筆記建立了「AI」、「處理器」和「AI PC」3個標籤，日後不管是在左邊工具面板的搜尋欄輸入，或是在右側工具面板點擊相關標籤，都能快速找到在這個標籤下的所有筆記。







    ![\"Obsidian標籤\"](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/q6c5-1761551058.png?w=600&output=webp\%22)  





在筆記中以「#」建立標籤後，在左右兩邊的工具欄都可以針對特定標籤做快速搜尋

 



圖／ Obsidian











## Obsidian教學4：如何「連結」不同筆記？



筆記連接功能是 Obsidian 這套筆記軟體最特別的地方，它採用了類似大腦神經元的連結方式，讓筆記之間形成一個知識網路，能透過關聯圖來一覽筆記之間的關聯。



雖說其他的筆記軟體也有連結功能，但通常都需要針對兩個文件進行個別連結設定。而在Obsidian 中，只要在筆記內建立一個單向連結，反向連結也會即時自動完成。



若想在 Obsidian 中建立連結：


1. 在文字的兩側連續輸入兩個**方括弧** `[[`。
2. 輸入兩個方括弧後，會跳出選單，列出筆記庫中各個筆記，可供選擇建立連結。
3. 也可以選擇創建新檔案。當連結的檔名不存在時，連結顏色會較淡（淺紫色），點擊該連結後，便能喚出新筆記。







    ![\"Obsidian連結\"](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/bs27-1761551179.jpg?w=600&output=webp\%22)  





在文字的兩側連續輸入兩個方括弧「\[\[」 建立連結頁面

 



圖／ Obsidian















    ![\"Obsidian連結\"](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/4fis-1761551251.png?w=600&output=webp\%22)  





建立新連結後，若連結非先前就有的頁面，也可以直接開啟撰寫新筆記

 



圖／ Obsidian











譬如，我們為NPU、GPU、CPU三個處理器筆記，以及AI PC、神經網路等概念建立連結後，即可在關聯圖中直觀地看到它們的關係。







    ![\"#0](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/1g3v-1761551341.png?w=600&output=webp\%22)  





設定好筆記間的連結，可以看到Obsidian將筆記間的關係串連起來

 



圖／ 數位時代















    ![\"#1](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/msw5-1761551342.png?w=600&output=webp\%22)  





NPU即為處理器，也是AI PC的重要元件，並且使用的是神經網路技術，這些要素會被歸類在NPU的類別下

 



圖／ 數位時代















    ![\"#2](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-10/pxcs-1761551342.png?w=600&output=webp\%22)  





透過Obsidian的關聯圖，能迅速理解筆記間的層級關係。

 



圖／ 數位時代











## 都是筆記軟體，Obsidian和Notion差在哪？



Obsidian 和 Notion 是兩個非常受歡迎的筆記工具，但兩者的功能重點和適用情境上有一些不同：

               

| 功能 | Obsidian | Notion |
| --- | --- | --- |
| 資料儲存 | 本地儲存為主，使用者完全掌握資料，隱私性高。 | 雲端儲存，資料儲存在 Notion 伺服器上。 |
| 核心設計 | 個人知識庫，強調筆記之間的連結 和知識圖譜，適合深度思考和建立知識網絡。 | 多功能工作區，結合了筆記、資料庫、專案管理、日曆等，功能更全面。 |
| 協作能力 | 主要設計給個人使用，若要多人協作需額外付費。 | 適合團隊共用資訊、專案管理和文件撰寫。 |
| 學習難點 | 需要熟悉Markdown語法，建立筆記間的連結 | 資料庫的設定與後續連結 |



簡單來說，如果你非常重視資料隱私、需要強大的雙向連結和知識網絡功能以及偏好離線工作，可以選擇Obsidian；如果你需要的是專案管理、資料庫和團隊協作功能，且不排斥將資料存放在雲端，那麼Notion這類型的多功能整合平台會更合適。



> 
> 
> 延伸閱讀：[實測｜NotebookLM「影片摘要」大升級：新增6種視覺風格，如何一鍵生成客製化教學影片？](https://www.bnext.com.tw/%22https://www.bnext.com.tw/article/84748/notebooklm-utilizes-nano-banana-to-enhance-video-overviews/%22)  
>  [Notion教學｜Notion是什麼？如何用它做筆記、管理專案？中文版設定、安裝方式一次看](https://www.bnext.com.tw/%22https://www.bnext.com.tw/article/81801/notion-tutorial/%22)
> 
> 



"\]


# 資料來源
2025/10/27: [Obsidian教學｜Obsidian是什麼？跟Notion差在哪？如何用它生成「知識網路」筆記？](https://www.bnext.com.tw/article/84880/obsidian-tutorial-2025) 