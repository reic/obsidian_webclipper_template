---
新聞來源: "TechNews 科技新報"
published: 2025-11-07
---
# 突破 AI 過熱瓶頸！科學家開發「纖維膜蒸發冷卻」，創超高效散熱表現
隨著人工智慧（AI）與雲端運算高速成長，散熱及冷卻成為供應商極需解決的問題。加州大學聖地牙哥分校的工程團隊研發一種創新的冷卻系統，以大幅提升資料中心與高效能電子裝置的能源效率。這項新技術利用特製的纖維膜，透過自然蒸發作用排除熱量，提供比傳統風扇、散熱片或液體幫浦更高效、省能的替代方案，也有望降低現有系統普遍高耗水的問題。

綜合外媒報導，研究團隊透過一種廉價的纖維膜，內含無數相互連結的微孔，可透過毛細作用將冷卻液引導至膜的表面。整個系統分成三層結構，底層是讓液體流通的微流道，中層為纖維膜所在位置，上層則是蒸發層。當液體蒸發時會帶走下方電子元件的熱量，全程不需額外供能。這項研究已經刊登在期刊《Joule》中。

該研究共同主持人之一、加州大學聖地牙哥分校雅各布工程學院機械與航太工程系教授 Renkun Chen 表示，與傳統的空氣冷卻或液體冷卻相比，蒸發冷卻能以更低能耗排出更高的熱通量。

Renkun Chen 表示，許多現有應用其實早已利用蒸發原理進行散熱，例如筆電內的熱導管、冷氣機中的蒸發器等，但這項技術要有效應用於高功率電子設備一直是項挑戰。

![](https://img.technews.tw/wp-content/uploads/2025/11/07170215/Evaporative-Cooling-Membrane-Schematic.jpg)

過去使用多孔膜的設計雖具備理想的蒸發表面積，但由於孔洞過小容易堵塞，或過大導致液體沸騰，最終都難以穩定運作。團隊這次採用孔徑適合且相互連結的多孔纖維膜，有助高效蒸發，同時避免過去系統常見的堵塞與沸騰問題。

更最令人關注的是，該系統創下每平方公分 800 瓦的熱通量紀錄，並能穩定運作數小時，展現出極高的散熱能力。研究團隊指出，這項技術仍遠未達理論上限，意味未來可望開發出性能更強、效率更高的版本，進一步提升資料中心的散熱效能。

這項成果展現了重新想像材料、開發全新應用的潛力。Renkun Chen 認為，這些纖維薄膜原本是為過濾用途設計的，從未有人探討其在蒸發冷卻方面的應用。但其結構特性獨特，因此成為高效蒸發冷卻的理想材料。

研究團隊目前正致力於改良薄膜並優化其性能，下一步將把它整合進冷卻板原型中，冷卻板可直接貼附在 CPU 或 GPU 晶片上以協助散熱。團隊也正籌備成立新創公司，推動該技術的商業化。

- [AI Is Overheating. This New Technology Could Be the Fix](https://scitechdaily.com/ai-is-overheating-this-new-technology-could-be-the-fix/)
- [Membrane evaporative cooling tech achieves record-breaking results, could be solution for next-generation AI server cooling — clocks 800 watts of heat flux per square centimeter](https://www.tomshardware.com/pc-components/cooling/membrane-evaporative-cooling-technology-achieves-record-breaking-results-could-be-a-solution-for-next-generation-ai-server-cooling-clocks-800-watts-of-heat-flux-per-square-centimeter)

（首圖來源：AI 生成）

### 延伸閱讀：

- [轉向長期布局、財測不如預期！多鄰國股價暴跌 25%「創史上新低」](https://finance.technews.tw/2025/11/07/duolingo-stock-and-2025-q3-financial-report/ "轉向長期布局、財測不如預期！多鄰國股價暴跌 25%「創史上新低」")
- [輝達與華為關係企業「共用園區」！美怒批：中國早已在後院潛伏多年](https://technews.tw/2025/11/07/nvidia-futurewei-location-near/)

# 資料來源
2025/11/07: [突破 AI 過熱瓶頸！科學家開發「纖維膜蒸發冷卻」，創超高效散熱表現](https://technews.tw/2025/11/07/new-technology-solved-ai-overheating-problem/) 