---
新聞來源: "電腦王阿達"
published: 2025-10-28
---
# xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲
## 資料還是偏少，而且還不支援中文的樣子

![Rocky](https://secure.gravatar.com/avatar/53fa886a03c5073b8758dac38c5a7fca2ef94397b2c86328ddb7029458b26d7f?s=80&d=mm&r=g) by

[2025 年 10 月 28 日](https://www.koc.com.tw/archives/618222)

in

525 次瀏覽

號稱超越的「Grokipedia」，稍早終於正式推出，所有內容都是由 撰寫，不過 有特別強調，內容已經由 進行事實查核。雖然馬斯克對這工具給予高度評價，但稍早我試用了一下，目前資料還是沒有很齊全，而且內容現階段只有英文，中文搜尋也有些問題，沒有說很好用，甚至有外媒發現到，Grokipedia 有一些內容是從維基百科複製過來。

![xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達](https://www.koc.com.tw/wp-content/uploads/2025/10/20251028110239_0_5a94d1.jpg "xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達")

## xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統的維基百科

馬斯克在今年 9 月時，就宣布過打造一個比 Wikipedia 維基百科更好的平台，也就是「 [Grokipedia](https://grokipedia.com/) 」，經過一段時間測試後，稍早終於正式上線。

跟維基百科不同，Grokipedia 是利用 Grok 語言模型來生成與維護內容，因此理論上可更快速擴充知識庫並修正錯誤。

Grokipedia 的介面非常簡潔，就只有一個搜尋框，跟一般的 AI 工具很像。另外下面會顯示目前已經收錄多少文章，寫這篇文章時是 88 萬多篇：  
![xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達](https://www.koc.com.tw/archives/www.w3.org/2000/svg'%20viewBox='0%200%201000%20607'%3E%3C/svg%3E "xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達")

於搜尋框中輸入關鍵字，如果有完全符合的文章，會直接顯示結果：  
![xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達](https://www.koc.com.tw/archives/www.w3.org/2000/svg'%20viewBox='0%200%20998%20614'%3E%3C/svg%3E "xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達")

進入文章後就能閱讀完整內容，內容非常長，絕大多數都比維基百科還多，而且在部分的句子後面，還會附上來源連結：  
![xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達](https://www.koc.com.tw/archives/www.w3.org/2000/svg'%20viewBox='0%200%201000%20703'%3E%3C/svg%3E "xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達")

文章最後也會有所有參考連結：  
![xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達](https://www.koc.com.tw/archives/www.w3.org/2000/svg'%20viewBox='0%200%201000%20495'%3E%3C/svg%3E "xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達")

中文部分現在都沒有任何結果：  
![xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達](https://www.koc.com.tw/archives/www.w3.org/2000/svg'%20viewBox='0%200%20911%20531'%3E%3C/svg%3E "xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達")

按下搜尋後，雖然會列出可能符合的結果，但完全不對，我明明輸入的是台積電，卻沒有出現 TSMC，而是一些蠻奇怪的文章，像是某某人名、2011 到 2020 的台灣戲劇等等。對 AI 來說，應該可以很容易知道台積電的英文是 TSMC，但現階段 Grokipedia 卻沒辦法：  
![xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達](https://www.koc.com.tw/archives/www.w3.org/2000/svg'%20viewBox='0%200%201000%20621'%3E%3C/svg%3E "xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達")

除此之外，外媒 The Verge 還發現到有一些內容跟維基百科一模一樣。

像是下圖的 PlayStation 5，一開始的內容，逐字逐句、段落結構都完全一樣：  
![xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達](https://www.koc.com.tw/archives/www.w3.org/2000/svg'%20viewBox='0%200%201000%20443'%3E%3C/svg%3E "xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達")

Lincoln Mark VIII 也是：  
![xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達](https://www.koc.com.tw/archives/www.w3.org/2000/svg'%20viewBox='0%200%201000%20439'%3E%3C/svg%3E "xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲 - 電腦王阿達")

The Verge 補充說，這不是 xAI 第一次被發現直接使用維基百科內容。上個月已經有使用者指出，Grok 的引用來源包含維基百科頁面後，馬斯克在回覆中表示：「我們會在年底前修好這個問題。」

可能是因為還沒到年底，所以現階段才會發生這種狀況。

雖然相較於過去，現階段的 AI 準確度已經高很多，非常少狀況才有可能給出錯誤資料，但要讓人完全相信 Grokipedia 內容都是對的，還需要一段時間考驗。不過從 Grokipedia 有內容抄襲維基百科來看，AI 在抓取資料和撰寫上，確實有受到嚴格限制。

至於什麼時候才會有中文，我覺得可能還要一段時間。

Tags:

No Result

View All Result

No Result

View All Result

# 資料來源
2025/10/28: [xAI 正式推出由 AI 驅動的「Grokipedia」，號稱超越傳統維基百科，但被外媒抓到部分內容完全抄襲](https://www.koc.com.tw/archives/618222) 