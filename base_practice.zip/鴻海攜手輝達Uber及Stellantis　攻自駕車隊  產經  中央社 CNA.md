---
新聞來源: "中央社 CNA"
published: 2025-10-29
---
# 鴻海攜手輝達Uber及Stellantis　攻自駕車隊 | 產經 | 中央社 CNA
（中央社記者鍾榮峰台北29日電）輝達（NVIDIA）GTC大會於美國華盛頓特區登場，鴻海今天上午宣布，攜手輝達、汽車品牌斯特蘭蒂斯集團（Stellantis）以及Uber，共同推動Level 4（無須手動操作、無須目視路況）自駕車開發與全球部署，用於自駕計程車（Robotaxi）服務。

鴻海透過英文新聞稿指出，在此合作案中，鴻海將發揮高效能運算、感測器整合與電子控制系統方面的能力；輝達以NVIDIA DRIVE AGX Thor車用電腦平台與AI輔助駕駛DRIVE AV軟體平台，提供人工智慧運算；Stellantis貢獻車輛平台；Uber提供全球規模交通移動網絡。

鴻海表示，四方形成聯盟推動自動駕駛技術應用，以NVIDIA DRIVE AGX Hyperion 10 架構為核心，開發具備Level 4能力的自動駕駛車。

鴻海董事長劉揚偉表示，自駕移動是鴻海電動車計畫中的戰略重點，透過與輝達、Stellantis與Uber策略合作，將加速Level 4自駕計程車技術實現。

輝達執行長黃仁勳表示，Level 4自動駕駛不僅是汽車產業的重要里程碑，更是人工智慧能力的一大躍進，車輛將成為智慧機器人，輝達結合Stellantis的全球規模與鴻海的系統整合，正在打造新一代專用自駕車隊。

鴻海說明，輝達將負責開發並提供Level 4自動停車與自動駕駛能力，Stellantis將設計、開發並製造自駕車並整合NVIDIA DRIVE AV系統。鴻海將與Stellantis合作進行硬體與系統整合。Uber則將負責自駕計程車服務營運，並擴張Stellantis製造、搭載 NVIDIA平台的車隊規模，推動全球自駕普及。（編輯：楊蘭軒）1141029

# 資料來源
2025/10/29: [鴻海攜手輝達Uber及Stellantis　攻自駕車隊 | 產經 | 中央社 CNA](https://www.cna.com.tw/news/afe/202510290034.aspx) 