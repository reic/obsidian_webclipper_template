---
新聞來源: "TechNews 科技新報"
published: 2025-10-14
---
# 2025 OCP 高峰會》強調開放互連重要性、宣布加入 ESUN 聯盟！AMD 談了哪些重要趨勢？
2025 年 OCP 高峰會（2025 OCP Global Summit）於美國時間 13 日在美國加州聖荷西正式展開，聚焦 AI 資料中心的開放架構、永續設計與高效運算。在首日主題演講中，AMD 技術長暨執行副總裁 Mark Papermaster 不斷重申開放生態系的重要性，AI 發展相當快速，「協作」不只是成功要素，更是根本條件，並強調歷史證明最終總是開放生態系勝出。

Papermaster 以「一個完全開放且協作的人工智慧生態系統」（A Fully Open and Collaborative AI Ecosystem）為題，表示 AI 無所不在，滲透到各個產業並改變整個工作流程與運作過程。在大型語言模型推動下，龐大的運算需求推升 GPU 的快速消耗，而隨著 Token 數量與上下文長度（context size） 的爆炸性成長，也推升對 CPU 需求，AMD 也看到更多專用加速器（specialized accelerators） 的出現。

根據 AMD 觀察，各國主權 AI 資料中心及企業級資料中心對 Gigawatt 等級規模的資料中心都有不同需求，涉及的資本支出也相當龐大，而 AMD 現在聚焦的是如何讓整個系統的總持有成本（TCO）達到最好。

首先，散熱和能源在設計中相當關鍵，開放軟體則確保可攜性、透明性與長期的彈性，這些優勢必須與「專有技術堆疊」（proprietary stacks）之間取得平衡。

接著，Papermaster 談到「開放」，認為推動產業變革的推手，與開放式協作（open collaboration）脫離不了關係，不管是 Linux、TCP/IP 與 HTTP、開放網頁技術都推動現代軟體、網路和瀏覽器的蓬勃發展。也因此，下一個關鍵潮流 AI 也需要開放生態系，這也是 OCP（Open Compute Project） 發揮關鍵之處。

### **全面開放 ROCm 與互連技術，AMD 宣布加入 ESUN 聯盟**

AMD 開放 AI 軟體堆疊 ROCm 及開放互連技術如 UCIe（通用晶片互連介面）、CXL（擴充介面）、UA Link（用於 Scale up）、還有 UEC（用於 Scale Out），都推動 AI 生態系的高速且永續擴張。

Papermaster 表示，AMD 今年重點放在全面開放 ROCm，打造一個充滿活力的開發者生態系，也加快軟體釋出節奏，強化對整個生態的支援，並提供開發者完整 AI 開發平台。

![](https://img.technews.tw/wp-content/uploads/2025/10/14120911/photo_2025-10-14_09-29-15.jpg)

至於機櫃級（rack-scale）系統部分，Papermaster 表示 AMD 致力於制定開放標準，首先在 Scale-out 部分，為產業提供更多擴展選擇，強化乙太網路在壅塞管理（congestion management）、封包分流（packet spraying）等挑戰。而 AMD 身為 UEC 創始成員，也專注於解決 HPC 與 AI 網路擴展需求。

![](https://img.technews.tw/wp-content/uploads/2025/10/14120906/photo_2025-10-14_09-28-26.jpg)

在 Scale-Up 部分，AMD 同樣是 UA Link 創始成員，目前已經開放核心互連架構「Infinity Fabric」，幫助 UA Link 聯盟在產業中迅速成長。同時，AMD 也宣布加入 ESUN（Ethernet for Scale-Up Networks）聯盟，目標是運用共通的乙太網路，同時支援多種運行於其上的傳輸協定。

Papermaster 指出，ESUN 將提供一個共同抽象層（common abstraction point），讓不同系統設計者能依需求，在使用共通乙太網基礎的同時，選擇最合適的傳輸協定，使整個乙太網生態系變得更具韌性、更多樣化。

針對 AMD 自身 Scale-Up 部署方案，可透過原生 UA Link 針對「GPU-GPU 直連」（direct GPU-to-GPU） 最佳化，支援相關 UA Link 的交換器（switch）也正開發中；AMD 也有在乙太網上實作 UA Link 標準的應用，目前已可透過現有的交換器基礎設施來支援。

透過 OCP、DC-MHS、UA Link 等開放標準，也造就了 AMD Helios 機架的模組化與互通性。

![](https://img.technews.tw/wp-content/uploads/2025/10/14120908/photo_2025-10-14_09-28-33.jpg)

Papermaster 表示，如果抽出其中一個模組單位，可看到裡頭有許多的開放標準，如 EPYC CPU 透過 PCIe 6.0 連接周邊設備；CXL 擴充介面；透過 Infinity Fabric 實現 CPU 與 GPU 間的直連傳輸；GPU 之間使用 UA Link 連接；Scale-Up 透過 UA Link over Ethernet 實現；管理模組採用 DC-SCM（硬體系統模組化的一部分）。

![](https://img.technews.tw/wp-content/uploads/2025/10/14120909/photo_2025-10-14_09-28-55.jpg)

### **機密運算、x86 對使用者社群重要性增加**

最後，Papermaster 認為兩件事情對使用者社群有重大意義，第一個是「機密運算」（Confidential Computing），機密變得更重要，因為企業微調模型時，會使用多年累積的關鍵數據，因此訓練後的模型、權重以及原始資料都必須受到嚴密保護。機密運算能確保安全性，並建立客戶在執行最關鍵應用程式時的信任與信心。

第二個是 x86 的重要性，去年 AMD 宣布成立「x86 生態諮詢小組」（x86 Ecosystem Advisory Group），並攜手英特爾，提高 x86 平台開發通用性、簡化軟體開發等工作。Papermaster 表示，透過與雲端巨頭、OEM 廠商以及作業系統領導者合作，AMD 推動在中斷模型結構（interrupt model structures）上的一致性，在指令集架構（ISA）擴充也達成共識，並強化記憶體安全等新功能。

Papermaster 表示，近期 NVIDIA 與英特爾的合作聲明，更突顯 x86 架構龐大的安裝基礎與這個生態系的健康活力，也對於 x86 生態諮詢小組的存在感到振奮。

（首圖來源：AMD）

### 延伸閱讀：

- [跨資料中心傳輸、光通訊成下一戰場！繼 Scale-Up、Scale-Out 後，NVIDIA 新喊出的 Scale-Across 是什麼？（上）](https://technews.tw/2025/09/30/silicon-photonics-scale-up-scale-out-scale-across/)
- [AI 晶片傳輸到 CPO 卡位戰：NVIDIA、博通到底在競爭什麼？（下）](https://technews.tw/2025/09/30/silicon-photonics-nvidia-broadcom/)

# 資料來源
2025/10/14: [2025 OCP 高峰會》強調開放互連重要性、宣布加入 ESUN 聯盟！AMD 談了哪些重要趨勢？](https://technews.tw/2025/10/14/amd-keynote-2025-ocp-global-summit/) 