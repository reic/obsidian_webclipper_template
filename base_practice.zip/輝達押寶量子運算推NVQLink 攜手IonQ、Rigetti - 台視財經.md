---
新聞來源: "台視"
published: 2025-10-29
---
# 輝達押寶量子運算推NVQLink 攜手IonQ、Rigetti - 台視財經
MoneyDJ新聞 2025-10-29 12:02:58 郭妍希 發佈輝達(Nvidia Corp.)尚不打算自行開發量子電腦，執行長黃仁勳(Jensen Huang)決定把賭注押在AI超級電腦與量子處理器之間的「NVQLink」連接技術解決方案。  
  
華爾街日報、CNBC等外電報導，黃仁勳28日在華盛頓D.C.舉行的GTC大會發表主題演說時表示，「NVQLink可說是連結量子與傳統超級電腦的羅塞塔石碑(Rosetta Stone，是破譯古埃及象形文字的關鍵)」。  
  

量子處理器(即QPU)代表全新的運算模式，利用量子物理學的原理破解當今傳統電腦難以解答的問題，有望為科學發現、金融模型等各項領域帶來重大革新。  
  
然而，若要產出對企業及研究人員有意義的結果，則須將量子處理器結合傳統超級電腦，執行先前難以解決的計算，並修正量子運算會自然產生的錯誤，也就是所謂的「錯誤校正」(error correction)。  
  
輝達工業工程與量子部門經理Tim Costa表示，業界普遍認為，結合QPU與輝達繪圖處理器(GPU)等AI晶片的混合型架構有其必要性，部分是因為需要AI來執行全方位的錯誤校正。  
  
Costa表示，有部分企業曾嘗試將QPU整合到AI超級電腦，最後卻發現其速度及規模無法滿足快速且大規模校正錯誤的需求。輝達最新的連結技術，是首款在速度、規模方面皆能真正支援大規模量子運算的解決方案。根據新聞稿，輝達與超過十家量子硬體製造業者攜手合作，當中包括Alice & Bob、Anyon Computing、Atom Computing、Diraq、Infleqtion、IonQ、IQM Quantum Computers、ORCA Computing、Oxford Quantum Circuits、Pasqal、Quandela、Quantinuum、Quantum Circuits, Inc.、Quantum Machines、Quantum Motion、QuEra、Rigetti、SEEQC及Silicon Quantum Computing。  
  
另外，輝達合作的量子控制系統製造商則包括Keysight Technologies、Quantum Machines、Qblox、QubiC及Zurich Instruments。  
  
IBM日前才成功運用超微(AMD)晶片執行一項重要的量子運算糾錯演算法。以AMD晶片執行量子運算糾錯演算法，為IBM實現2029年底前造出量子電腦目標的關鍵里程碑。IBM研究部負責人Jay Gambetta當時表示，這顯示IBM的演算法不僅能在現實世界成功運作，且靠的還是「並未貴到離譜」的AMD現有晶片。  
  
(圖片來源：shutterstock)＊編者按：本文僅供參考之用，並不構成要約、招攬或邀請、誘使、任何不論種類或形式之申述或訂立任何建議及推薦，讀者務請運用個人獨立思考能力，自行作出投資決定，如因相關建議招致損失，概與《精實財經媒體》、編者及作者無涉。

# 資料來源
: [輝達押寶量子運算推NVQLink 攜手IonQ、Rigetti - 台視財經](https://www.ttv.com.tw/finance/view/102025291202AB57ED186E1146F1B3DA13100F74BE8BAC5E/587) 