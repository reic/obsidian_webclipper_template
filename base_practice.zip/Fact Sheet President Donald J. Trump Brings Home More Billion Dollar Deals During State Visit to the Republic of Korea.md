---
新聞來源: "The White House"
published: 2025-10-29
---
# 白宮發布川普訪韓雙邊經濟協議
# 重點摘要

## 航空國防：奠定戰略合作基石

- Korean Air承諾購買103架Boeing新型客機，總值362億美元，預計將為美國創造多達13.5萬個就業機會。為搭配這批新機隊，Korean Air另外簽署137億美元的合約，向GE Aerospace採購最先進的航空引擎，總計近500億美元。
- 韓國空軍選定L3 Harris Technologies開發新一代空中預警管制機（Airborne Warning and Control）系統，合約金額達23億美元，將支持超過6,000個美國就業機會。
- 美國ReElement Technologies與POSCO International達成合作協議，將在美國本土建立垂直整合的稀土分離、精煉及磁鐵生產基地，專注於高價值移動磁鐵的生產。

## 能源主導：鞏固美國全球地位

- Korea Gas Corporation簽署長期採購協議，承諾每年購買約330萬噸美國液化天然氣（LNG）。採購將透過Trafigura和Total Energy等供應商進行，最終來自Cheniere等美國LNG生產商。
- Centrus Energy Corp、Korea Hydro & Nuclear Power（KHNP）及POSCO International Corporation達成三方協議，支援 Centrus位於俄亥俄州Piketon的鈾濃縮產能擴建，預計將創造3,000個美國就業機會。
- LS Group承諾在2030年前投資30億美元於美國電網基礎設施，包括海底電纜、電力設備和繞線。LS Cable的美國子公司LS Greenlink正在維吉尼亞州建設6.81億美元的製造設施。

## 科技革命：引領數位經濟未來

- 在科技領域，美韓簽署了《科技繁榮協議》（Technology Prosperity Deal），擴大雙邊科學技術合作，聚焦於美國AI出口、AI標準制定、AI採用、研究安全、6G通訊、生技供應鏈及量子創新等前沿領域，旨在確保美國在全球技術競賽中的領先地位。
- Amazon宣布將在2031年前投資50億美元建設韓國的雲端基礎設施，這不僅推動美國技術出口，更鞏固美國在AI領域的領導地位。這項投資是Amazon Web Services（AWS）在川普任內於14個APEC經濟體累計400億美元雲端基礎建設投資的一部分，展現了美國科技巨頭在全球數位經濟中的主導角色。
- 太空合作方面，NASA的Artemis II任務將搭載韓國衛星，在自Apollo計畫後首次載人繞月任務中測量太空輻射。這項合作標誌著美韓太空夥伴關係進入新階段。
- 雙方也承諾透過公私合作穩定和多元化關鍵礦產供應鏈，涵蓋礦產開採和精煉等環節，以應對全球供應鏈重組的挑戰。

## 造船復興：重建美國海事實力

- HD Hyundai與Cerberus Capital Management建立戰略夥伴關係，啟動50億美元投資計畫，旨在現代化美國造船廠、強化供應鏈，並應用自主導航、數位化和自動化等新技術。這項投資將為長期式微的美國造船業注入新生命。
- Samsung Heavy Industries與Vigor Marine Group達成合作協議，聚焦於海軍艦艇的維修、修理及檢修（MRO）、船廠自動化，以及新建美國籍船舶。這項合作將提升美國海軍維修能力，並創造大量高技能就業機會。
- Hanwha Ocean宣布50億美元基礎建設計畫，將強化賓州費城造船廠（Philly Shipyard）的勞動力，並將其產能擴增超過十倍。這項計畫象徵著美國造船業復興的決心，也為當地社區帶來可觀的經濟效益。

## 貿易協議：平衡關稅與投資

- 美韓就涵蓋投資及造船領域的廣泛貿易協議達成共識。根據協議，美國對韓國商品徵收的對等關稅將從25%降至15%，汽車及汽車零件關稅也同步降至15%，與日本、歐盟享有相同待遇。半導體方面，韓國獲得不高於台灣的關稅水準，確保了公平競爭環境。
- 特定產品獲得更優惠待遇：醫藥品和木材產品享有最惠國待遇；航空器零組件、學名藥，以及美國境內未生產的天然資源則完全免徵關稅。值得注意的是，韓國成功阻止了包含稻米、牛肉在內的農業領域追加開放要求。
- 作為交換，韓國承諾對美投資總額達3,500億美元，其中2,000億美元為現金投資，1,500億美元用於造船產業合作。為降低對韓國外匯市場的衝擊，協議設置年度投資上限為200億美元，並採用分批撥款機制。投資將透過傘型特殊目的公司（Umbrella SPC）管理，由美國商務部長Howard Lutnick擔任投資委員會主席。
- 這項投資方案設計了多重保障機制：僅推動具商業合理性、保障本金利息的項目；本息償還前韓美收益5:5分配；若20年內無法全額收回本息，可調整收益分配比例；特定項目虧損可由其他項目盈餘彌補。若外匯市場不穩定，韓方有權申請調整投資時程和金額。

## 韓國
韓國政府(總統辦公室政策室)，室長金容范在慶州召開記者會宣布協議細節。以下為協議內容的正式公告：

**一、投資協議**
1. **總投資額**：3500億美元，分為：
	- 現金投資：2000億美元（年度投資上限：200億美元）
	- **造船業合作**：1500億美元
2. **投資原則：**
	- 投資按年度進行，採用非市場買入方式籌資，降低對外匯市場衝擊。
	- 設有外匯市場調整機制，若市場不穩定可申請調整投資時程和金額，確保投資項目的商業合理性和回報。

**二、關稅調整**

1. **汽車關稅**：從20%調降至15%
2. 藥品、木製品：適用最惠國待遇
3. 航空器零件、仿製藥品、美國內不生產的天然資源：免稅
4. **半導體：確保與主要競爭國（如臺灣）相比，不具不利條件的關稅水平。**
5. 農業產品（如米、牛肉）：無進一步開放。

**三、外匯市場考量**

1. **年度投資上限**：200億美元，確保不超越韓國外匯市場的承受能力。
2. **彈性調整機制**：在外匯市場出現不確定性時，可調整投資時間和金額。
3. **長期投資安排**：投資實施期間長，通過非市場購買方式減少對外匯市場的影響。

**四、投資安全機制**

1. **多層安全保障**：確保投資項目的原本和利息回報。
2. **利益分配**：投資期間內，利益按5:5分配；若20年內未完全回收本金，利益分配比例可調整。
3. **特殊目的公司（SPC）結構**：采用雨傘式結構，降低投資風險。

**五、後續安排**

1. **協議執行**：確保投資項目的實施，強化韓美兩國的工業供應鏈合作。
2. **韓國企業參與**：美國同意在投資計畫中優先選擇韓國企業，並聘用韓國人擔任計畫經理。

韓國政府評估，此協議大幅減輕了對韓國外匯市場的實質性負擔，為韓國企業在美國的市場競爭條件提供了保障。協議的具體化，將大幅降低市場不確定性，促進韓國企業進入美國市場。

- [한미, 관세협상 타결…자동차관세 15%·현금투자 연 200억 달러 상한 - 2025 경주 APEC | 정책포커스 | 뉴스 | 대한민국 정책브리핑](https://www.korea.kr/news/policyFocusView.do?newsId=148953418&bbsKey=&pageIndex=1&pkgId=49500822&pkgSubId=&pkgSubs=&exceptNewsId=&cardYn=&cateId=&cateIds=&sectId=&sectIds=&nCateIds=&nSectIds=&dataValue=&srchWord=&repCode=&repText=&allYn=)
# Fact Sheet: President Donald J. Trump Brings Home More Billion Dollar Deals During State Visit to the Republic of Korea

The White House

**SECURING BILLIONS IN EXPORTS AND INVESTMENTS:** Today,President Donald J. Trump completed the final stop of his historic Indo-Pacific trip, securing billions in landmark deals while visiting the Republic of Korea (ROK), including initiatives to support American jobs, further America’s energy dominance, promote American leadership in the technology revolution, and build our maritime partnership.

- Korean Air will purchase 103 new Boeing aircraft valued at $36.2 billion, supporting up to 135,000 jobs across the United States. To power these new aircraft, Korean Air will also purchase state-of-the-art GE Aerospace engines in a separate deal valued at $13.7 billion.
- The ROK Air Force selected L3Harris Technologies to develop its new Airborne Warning and Control aircraft in a $2.3 billion deal that will support over 6,000 American jobs.
- America’s ReElement Technologies and POSCO International will partner to launch a U.S.-based, vertically integrated rare earth separation, refining, and magnet production complex focused on high-value mobility magnets.

**FURTHERING AMERICA’S ENERGY DOMINANCE:** The President secured key investments further solidifying the United States’ position as the global energy leader.

- The Korea Gas Corporation signed agreements to purchase about 3.3 million tons/year of U.S. LNG via long-term agreements with sellers, including Trafigura and TotalEnergy, through their portfolios and offtake agreements with U.S. LNG producers like Cheniere.
- Centrus Energy Corp, KHNP, and POSCO International Corporation agreed to support the expansion of Centrus’ uranium enrichment capacity in Piketon, Ohio, creating 3,000 jobs in the United States.
- LS Group pledged to invest $3 billion by 2030 in U.S. power-grid infrastructure, including undersea cables, power equipment, and winding wires. LS Cable’s U.S. subsidiary, LS Greenlink, is building a $681 million manufacturing facility in Virginia.

**PROMOTING AMERICA’S ADVANTAGE IN THE TECHNOLOGY REVOLUTION:** The President strengthened America’s leading role in the digitized economy by boosting investments and jobs in, and access to, U.S. technology.

- The United States and the ROK are signing a Technology Prosperity Deal to expand bilateral science and technology cooperation with an emphasis on U.S. AI exports, AI standards, AI adoption, research security, 6G, biotech supply chains, and quantum innovation.
- Amazon will invest $5 billion through 2031 to build the ROK’s cloud infrastructure, helping drive U.S. exports and American AI leadership. This comes on top of Amazon Web Services’ (AWS’) historic cloud-infrastructure investments across 14 APEC economies during the President’s term, totaling $40 billion.
- NASA’s Artemis II mission will take astronauts around the Moon for the first time since Apollo, and deploy a Korean satellite to measure space radiation.
- Both countries committed to stabilize and diversify the critical-mineral supply chain through public-private collaboration in the mining and refining of such minerals.

**BUILDING OUR MARITIME PARTNERSHIP:** The President has secured from the ROK investments to modernize and expand the capacity of American shipbuilding industries, including through investments in U.S. shipyards and America’s workforce.

- HD Hyundai and Cerberus Capital Management will partner on a $5 billion investment program for modernizing American shipyards, strengthening supply chains, and applying new technologies like autonomous navigation, digitalization, and automation.
- Samsung Heavy Industries and Vigor Marine Group will cooperate on naval vessel maintenance, repair, and overhaul (MRO), shipyard automation, and new construction of U.S.-flagged vessels.
- Hanwha Ocean announced a $5 billion infrastructure plan to strengthen Pennsylvania’s Philly Shipyard workforce and increase its current production capacity by more than ten-fold.

**REESTABLISHING AMERICAN LEADERSHIP:** President Trump’s State Visit to Korea reaffirmed the steadfast alliance between the United States and the ROK, while advancing U.S. economic interests—delivering tangible benefits for the American people.

- This capstone stop on President Trump’s Asia travels underscored America’s prominent role as the preeminent Pacific power.
- Today’s announcements build on the historic trade victories and infrastructure commitments the President secured while in Japan and Malaysia, bringing billions in investments and thousands of jobs home to America.

![](https://www.whitehouse.gov/wp-content/uploads/2025/02/Wire-Banner.jpg)

![](https://www.whitehouse.gov/wp-content/uploads/2025/09/wire-banner-mobile.jpg)

# 資料來源
2025/10/29: [Fact Sheet: President Donald J. Trump Brings Home More Billion Dollar Deals During State Visit to the Republic of Korea](https://www.whitehouse.gov/fact-sheets/2025/10/fact-sheet-president-donald-j-trump-brings-home-more-billion-dollar-deals-during-state-visit-to-the-republic-of-korea/) 