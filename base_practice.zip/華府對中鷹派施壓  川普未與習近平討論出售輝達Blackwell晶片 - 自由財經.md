---
新聞來源: "自由時報電子報"
published: 2025-10-30
---
# 華府對中鷹派施壓  川普未與習近平討論出售輝達Blackwell晶片 - 自由財經
[![川普10月30日表示，他並未與習近平討論批准輝達 Blackwell 系列 AI晶片銷往中國一事。（美聯社）](https://img.ltn.com.tw/Upload/business/page/800/2025/10/30/5229385_1.jpg)](https://img.ltn.com.tw/Upload/business/page/800/2025/10/30/5229385_1.jpg "川普10月30日表示，他並未與習近平討論批准輝達 Blackwell 系列 AI晶片銷往中國一事。（美聯社）")川普10月30日表示，他並未與習近平討論批准輝達 Blackwell 系列 AI晶片銷往中國一事。（美聯社）

〔編譯盧永山／綜合報導〕美國總統川普10月30日表示，他並未與中國國家主席習近平討論批准輝達 Blackwell 系列人工智慧（ AI）晶片銷往中國一事，澆熄市場對美國可能放寬出口管制的預期。川普29日暗示他可能協助輝達向中國出口「降規版」Blackwell晶片，引發現任、卸任官員與國會議員的批評，認為若美國放行，將是重大的「國安錯誤」。

《彭博》報導，川普與習近平10月30日在南韓舉行的亞太經合會（APEC）領袖峰會場邊進行「川習會」，會談一結束他啟程返美，並在空軍一號上對媒體表示，他與習近平談到輝達進入中國的情況，並說輝達將繼續就採購晶片事宜與北京當局進行對話。被問及美國是否會批准向中國出口降規版的Blackwell晶片時，川普指出，「我們沒有討論Blackwell晶片」。

請繼續往下閱讀...

<iframe id="google_ads_iframe_/21202031/06-ec-sub-P-IR1_0" name="google_ads_iframe_/21202031/06-ec-sub-P-IR1_0" title="3rd party ad content" width="797" height="250" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" aria-label="Advertisement" tabindex="0" allow="private-state-token-redemption;attribution-reporting" style="border: 0px; vertical-align: bottom;" data-google-container-id="6" data-load-complete="true"></iframe>

川普10月29日表示，將與習近平討論輝達Blackwell系列產品，這是為了達成美中全面貿易協議的更廣泛會談一部分。《紐約時報》報導，川普這番言論引發投資人預期華府將會放行，導致輝達股價大漲，市值突破5兆美元（新台幣154兆元），卻令華府許多對中鷹派人士擔憂，此舉將使北京取得先進AI晶片，進而使中國解放軍取得軍事優勢，對美國國家安全構成風險。

民主黨聯邦參議員昆斯（Chris Coons）表示，川普的談話令他擔憂，「定義21世紀戰鬥的是誰控制了AI，對川普總統而言，為了從中國拿到一些黃豆訂單，而向他們出售這些關鍵的尖端AI晶片，這是個悲劇性錯誤。」

前美國駐中國大使、目前擔任哈佛大學教授的伯恩斯（Nicholas Burns）表示，他希望川普政府能就出售美國技術給中國一事「堅守底線」，並說若美國若真的向中國出售輝達降規版Blackwell晶片，將是巨大的錯誤。

伯恩斯指出，如果中國軍方因為在未來10年採用更好的技術而變強大，對美國或日本、南韓和印度等盟友的後果將很悲慘，美國企業向中國銷售所取得的任何利益很可能是非常短暫的，因中國政府希望在晶片技術方面自力更生，正如在其他產業一樣。

伯恩斯強調：「這個損失是難以計算的，我們必須把國家安全擺在任何一家企業的利益之上。」

一手掌握經濟脈動 [點我訂閱自由財經Youtube頻道](https://www.youtube.com/channel/UCdm3nYbbJ3gcbbOWhGDNqhw "點我訂閱自由財經Youtube頻道")

 [*免費訂閱***《自由體育》電子報**

熱門賽事、球星動態不漏接

](https://edm.ltn.com.tw/?utm_source=LTNWEB&utm_medium=articleEnd&utm_campaign=newsletter-sports-subs "訂閱電子報")

不用抽 不用搶 現在用APP看新聞 保證天天中獎　 [點我下載APP](https://service.ltn.com.tw/app "點我下載APP")　 [按我看活動辦法](https://drawpage.ltn.com.tw/slot_v9/ "按我看活動辦法")

# 資料來源
2025/10/30: [華府對中鷹派施壓  川普未與習近平討論出售輝達Blackwell晶片 - 自由財經](https://ec.ltn.com.tw/article/breakingnews/5229385) 