---
新聞來源: "經濟日報"
published: 2025-10-29
---
# 黃仁勳 GTC 登場 法人看好鴻海、廣達等供應鏈受惠 | 產業熱點 | 產業 | 經濟日報

黃仁勳於2025年輝達（NVIDIA）GTC大會進行主題演講，直指輝達GPU市場需求依然旺盛，同時與美國能源部合作打造七座新超級電腦，也和多元產業進行結盟，包括與Uber、禮來等，並布局6G和量子運算市場，法人看好鴻海[（2317）](https://money.udn.com/industry/company/2317)、廣達[（2382）](https://money.udn.com/industry/company/2382)等供應鏈將受惠。

NVIDIA於華盛頓特區舉行為期三天的GTC大會，探討AI發展前景，執行長黃仁勳在演講中公布多項與產業夥伴共同推動的人工智慧項目，強化NVIDIA的核心地位，並也討論到其在AI、6G通訊、量子運算、機器人技術等領域的發展。

黃仁勳強調AI 是這個時代最強大的技術，而科學是其最偉大的前沿，針對AI泡沫論提出反駁，認為使用者正在運用各種不同的AI模型，並樂於為此付費，證明昂貴的運算基礎設施建設是合理的。同時也指出，NVIDIA的GPU市場需求依然旺盛，採用Blackwell架構的GPU晶片，以及預計明年上、採用Rubin架構的新晶片，可望使整體GPU銷售額在2026年底達到5000億美元。

此外，宣布將與美國能源部合作打造七座新超級電腦，最大規模的一座將與Oracle共同建置。也與多元產業結盟，包括與Uber合作自動駕駛車隊、向禮來出售1，000顆GPU等。其中，與Nokia合作6G技術開發並為基地台打造晶片，Nokia 將採用名為「Nvidia ARC」的新產品，展現出NVIDIA將布局次世代6G網路傳送的AI技術，因此計畫投資10億美元，購入逾1.6億股的Nokia股票。

法人機構表示，市場對此次演講反應較為樂觀，短期將對於台灣相關供應鏈如鴻海、廣達、緯創[（3231）](https://money.udn.com/industry/company/3231)、神達[（3706）](https://money.udn.com/industry/company/3706)、英業達[（2356）](https://money.udn.com/industry/company/2356)、技嘉[（2376）](https://money.udn.com/industry/company/2376)、華擎[（3515）](https://money.udn.com/industry/company/3515)、華碩[（2357）](https://money.udn.com/industry/company/2357)等下游廠商有所激勵，正向看待AI產業未來發展。

# 資料來源
2025/10/29: [黃仁勳 GTC 登場 法人看好鴻海、廣達等供應鏈受惠 | 產業熱點 | 產業 | 經濟日報](https://money.udn.com/money/story/5612/9103247?from=edn_search_result) 