---
新聞來源: "TechOrange 科技報橘"
published: 2025-11-03
---
# 【AI 整理新聞普遍有錯】主流 AI 被考倒，ChatGPT、Copilot、Gemini、Perplexity 都翻車
![先別用 AI 幫你讀新聞！研究指資訊錯誤率高達 76%，連教宗生死都搞不清楚](https://techorange.com/app/uploads/2025/10/f2f01defee135cc6.jpg)

面對資訊爆炸的時代，你現在都怎麼閱讀新聞？自從 AI 聊天機器人開始蓬勃發展，有些人已經很習慣透過 AI 工具，整理網路上的新聞並摘要重點。根據路透社研究所發布的《2025 年數位新聞報告》， **大約有 7% 的線上新聞閱讀者，以及 15% 的 25 歲以下民眾，都是透過 AI 助理取得新聞。**

然而，最新研究卻發現 AI 助理的新聞資訊錯誤頻繁，相當於 AI 所理解的新聞內容，超過一半含錯誤或問題，進而助長假訊息的傳播。

## 主流 AI 都被新聞考倒

根據歐洲廣播聯盟（EBU）和英國廣播公司（BBC）日前發表的最新 [研究](https://www.bbc.com/mediacentre/2025/new-ebu-research-ai-assistants-news-content) ，目前市場上領先的人工智慧助理，包含 OpenAI ChatGPT、Microsoft Copilot、Google Gemini 和 Perplexity 等，對於新聞內容的傳達都擁有極大問題。

這項規模空前且廣泛的國際深入研究，事實上是在那不勒斯的歐洲廣播聯盟新聞大會上所啟動，涉及 18 個國家／地區，總共 22 個公共服務媒體（PSM）組織，橫跨多達 14 種語言，目標為測試出 AI 對於新聞的正確理解程度。

結果發現，在 ChatGPT、Copilot、Gemini 和 Perplexity 共同回答了 3,000 多道跟新聞相關的問題之後，高達 45% 由 AI 所給出的回應，至少都帶有一項重大錯誤。

此外，亦有 31% 的 AI 回應，存在有十分嚴重的引用問題，比方說缺少來源連結，或者使用了具備誤導性、錯誤的引用標註。

## 來源出問題，Gemini 表現最差

EBU 和 BBC 的研究進一步指出，人工智慧所理解的新聞內容，約 20% 存在重大的準確性問題，例如 AI 會「虛構」的新聞的故事細節，以及提供早就過時的無效資訊。

舉例來說，Google Gemini 在「電子煙相關法律」的新聞動態整理方面，有著完全錯誤的陳述；而 ChatGPT 則在前任教宗方濟各去世的幾個月後，繼續將他列為現任教宗。

該研究也特別點出， **Google Gemini 於測試中的表現最差，超過 70% 的回覆都存在問題** ，比率為其他 AI 助手的兩倍以上，原因可能在於 Gemini 所引用的新聞資料來源，較其他 AI 工具有所欠缺，品質相對也更加糟糕。

## 主打正確率的 Perplexity 也翻車

面對這種尷尬的情況，各家科技巨頭都沒有第一時間作出回應。

先前 Google 曾在網站上主動表示，歡迎各界提供回饋意見，協助開發團隊繼續改進 Gemini 及 AI 平台；OpenAI 和微軟則指出，AI 本身所擁有的幻覺問題，本就會造成虛假資訊頻繁出現，而他們也正在積極尋找解決方案。

即便是曾經大聲表明，其「深度研究」模式正確率高達 93.9% 的 Perplexity，這次也在新聞領域中箭落馬，令外界不得不對 AI 的準確度再次提高警覺。

## AI 出問題，連帶影響媒體誠信

歐洲廣播聯盟媒體總監兼副秘書長 Jean Philip De Tender 強調，這項研究明確指出，AI 在新聞正確性方面的缺陷，並非是獨立事件，而是具備系統性、跨國性與多語言性，甚至危及了公眾對於媒體的信任。

Jean Philip De Tender 說， **如果 AI 傳達虛假消息的情況持續，那麼當人們不知道可以相信什麼時，最終就會對一切失去信任，並且削弱民主參與的意願。**

**另一份由 BBC 所進行的研究也指出，超過三分之一的英國成年人，完全信任由 AI 所生成的重點摘要，而 35 歲以下群體的信任度更將近二分之一。**

結合兩份研究結果後，即不難見出其中的重大隱憂，即許多人都誤以為 AI 生成的新聞摘要內容足夠精準，但實際情況卻完全不是這樣。

不僅如此，當 AI 出現錯誤時，民眾不只會把責任歸咎給新聞媒體，更會將矛頭指向 AI 開發者，即便這些錯誤是由於人工智慧模型本身的缺陷所造成，然而大眾對於新聞內容及品牌的信任度，依然會因此遭到削弱。

## 研究團隊推指引，媒體仍寄望 AI

在 EBU 和 BBC 的研究出爐後，他們也同時推出了《人工智慧助理新聞誠信指引》，希望協助媒體業與 AI 開發商，解決報告中所揭露的各項問題。

該指引主要瞄準兩大改進方向，包含提升 AI 助理的回應品質，以及增進使用者的媒體素養。同時，研究團隊也聚焦解答兩大核心問題，即「何謂優質的人工智慧助理新聞回應？」，還有「哪些重大問題尚待修正？」

BBC 生成式 AI 節目總監 Peter Archer 認為，媒體業對人工智慧充滿期待，畢竟 AI 確實能夠協助媒體組織，為觀眾創造出更多價值。

只不過，應用 AI 的前提仍在於民眾必須能夠信任，他們所閱讀、觀看到的資訊內容，儘管相較過去 AI 助理的準確度已經有所改善，但是這些輔助工具顯然還是具備嚴重問題有待解決。

Peter Archer 強調，媒體業仍就期盼 AI 工具能順利發展，當然他們也樂意跟人工智慧公司合作，為觀眾及社會創造更廣泛的價值。

> **【推薦閱讀】**
> 
> [◆ 從「每個人都能改」到「只有 AI 能寫」，馬斯克的 Grokipedia 讓知識生產更快也更危險](https://techorange.com/2025/10/28/grokipedia-elon-musk/)  
> [◆ AI 讓資安誤報增加？AI 幻覺捏造的「不存在漏洞」正讓資安人員疲於應對](https://techorange.com/2025/07/29/ai-slop-cybersecurity/)  
> [◆ 【全球最大對話社群：ChatGPT】10% 成年人都跟它聊，AI 不只回答還主導決策方向](https://techorange.com/2025/10/18/report-people-using-chatgpt/)

＊本文開放合作夥伴轉載，參考資料： [《Reuters》](https://www.reuters.com/business/media-telecom/ai-assistants-make-widespread-errors-about-news-new-research-shows-2025-10-21/) 、 [《Computerworld》](https://www.computerworld.com/article/4077344/ai-chatbots-are-wrong-about-news-45-of-the-time.html) ，首圖來源： [Pexels](https://www.pexels.com/photo/news-on-laptop-screen-17706646/)

（責任編輯：鄒家彥）

![](https://sslcode.adgeek.com.tw/public/images/popad_close_button.png)

# 資料來源
2025/11/03: [【AI 整理新聞普遍有錯】主流 AI 被考倒，ChatGPT、Copilot、Gemini、Perplexity 都翻車](https://techorange.com/2025/11/03/ai-assistant-error-news-bbc/) 