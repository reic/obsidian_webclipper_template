---
新聞來源: "數位時代 BusinessNext"
published: 2025-11-03
---
# AI搶了他們的工作！哈佛研究：愛用AI的企業不愛找小菜鳥，中等大學畢業比後段班更沒頭路
AI取代各行各業職位的衝擊早已被各界議論紛紛，[新鮮人難找工作的狀況也時有所聞](https://www.bnext.com.tw/%22https://www.bnext.com.tw/article/84327/three-years-of-experience-barrier/%22)，近期，哈佛大學研究人員便以數據證實：AI搶走的，就是這群人的飯碗。



哈佛大學研究人員Seyed M. Hosseini和Guy Lichtinger近日發表論文《生成式AI是一種資歷偏向的技術變革》（Generative AI as Seniority-Biased Technological Change: Evidence from U.S. Résumé and Job Posting Data  
），其中透過研究2015年至2025年美國近28.5萬家公司、6,500萬員工的資料，並追蹤近2億個職缺發布發現，AI確實導致了就業人數下滑，而以資淺員工受到的衝擊最為嚴重。



該研究發現， **資淺的新鮮人是被AI搶工作的重災區** ，另外一群人則是「中等大學」的畢業生，甚至比「學店」出身者受到AI的衝擊更嚴重。





掌握最新AI、半導體、數位趨勢！訂閱《數位時代》日報及社群活動訊息







謝謝訂閱😊  
祝你有美好的一天





      

 



  

 









請稍等



 ![](https://www.bnext.com.tw/%22https://cdn.bnextmedia.com.tw/assets/bnextmedia/circled-right.gif/%22)



















## 發現一：擁抱AI的企業不愛找新人，資深員工工作依舊穩



這份研究主要將企業與員工各自分成兩種類型。首先是透過企業發布的職位，將企業分為擁抱AI的企業、未擁抱AI的企業，並將員工依照職位分成資淺組和資深組。



先從結論說起，這份研究的核心發現是，擁抱AI的企業資淺員工就業人數顯著下滑，而無論是否擁抱AI技術，企業的資深員工人數保持穩定成長，沒有太大變化。從ChatGPT登場後6個季度內，擁抱AI企業的資淺員工就業人數，相對於未採用AI公司的資淺員工人數，出現了約9%的下滑。



且資淺員工人數減少的主因並非裁員或者升官，而是擁抱AI的企業紛紛放慢招募的腳步。不過研究中提到，這不代表這些企業將入門工作自動化，用AI直接「取代」了資淺員工。也有可能是企業主預估部分工作未來將被自動化，因此先一步減少人力招募，導致資淺員工人數下滑。



雖然擁抱AI的公司大多來自資訊產業及專業服務業，但資淺員工招募下滑卻是跨產業的現象，並不是由個別產業主導所致。



 ➜ [別讓 MarTech 內耗你的行銷戰力🫵 從「工具失靈」到「整合斷點」，建立無縫行銷生態圈｜LINE現場分享 ](https://www.bnext.com.tw/%22https://edm.bnext.com.tw/martech-trends/?utm_campaign=2025martech&utm_source=web_bn&utm_medium=middle_text&utm_content=144394&utm_term=channel_1\%22 "\\"別讓") 



具體而言，研究中指出，擁抱AI的企業在2023年第一季後平均每季度減少雇用5名資淺員工，並且主要集中於容易受生成式AI影響，或者面臨自動化風險較高的職位，例如軟體開發人員、編輯、作家、客服等等。



> 
> 
> 延伸閱讀：[Z世代職場最難跨過的坎：3年經驗！AI掀起就業困境該怎麼解？](https://www.bnext.com.tw/%22https://www.bnext.com.tw/article/84327/three-years-of-experience-barrier/%22)
> 
> 



## 發現二：畢業自「中段班」學校的員工，受創最深



有趣的是，研究中還將資淺員工的畢業學校分成Tier 1到Tier 5等5個類別，Tier 1是最富盛名的常春藤院校等學校，而Tier 5則充斥著「學店」等級的劣質大學。結果發現， **受AI衝擊最嚴重的不是Tier 5學校出身的資淺員工，反而是來自Tier 3、Tier 4這些中等學校的員工** ，受到AI影響最大。







    ![\"Gemini](https://www.bnext.com.tw/%22https://image-cdn.learnin.tw/bnextmedia/image/album/2025-09/img-1758866930-61357.jpg?w=600&output=webp\%22)  



 



圖／ Gemini











實際上，研究中發現被AI取代的風險是隨著學校Tier上升而成長，但Tier 1、Tier 2精英人才擁有更高的價值，即使他們的工作有可能被AI取代，企業仍然願意保留人才，提供他們其他的機會。



而Tier 5的低階人才則因為工作本身就較不容易被取代，因此較AI衝擊的程度也較中等學校的人才為低。



> 
> 
> 延伸閱讀：[Gemini也能做簡報了！3步驟教學：Canvas模式一鍵生成，還能無縫匯入Google簡報](https://www.bnext.com.tw/%22https://www.bnext.com.tw/article/84938/gemini-canva/%22)
> 
> 



## 基層員工不足，恐造成企業人才空窗



研究中擔憂，這種資淺員工招募顯著下滑的情況，可能導致「職涯階梯」中斷或受到侵蝕的風險。一般來說，企業員工往往是從基層做起，逐漸累積經驗並向上晉升，但AI可能使得這樣不斷向上攀爬的職涯階梯不再起作用。



這可能使企業出現人才空窗的問題，入門級職位的消失讓年輕人失去累積經驗、培養技能的地方，導致未來具備高階職位所需能力的人才不足。



另外，研究中提到，職涯早期的收入對終生的收入軌跡有著強烈影響，擔心現在新鮮人難找工作的狀況，可能對他們的終生收入造成負面影響，加劇收入不平等的問題。



完整報告請見：[Generative AI as Seniority-Biased Technological Change:Evidence from U.S. R´esum´e and Job Posting Data](https://www.bnext.com.tw/%22https://papers.ssrn.com/sol3/papers.cfm?abstract_id=5425555\%22)



> 
> 
> 延伸閱讀：[在半導體業打拚30多年！台積電「研發6騎士」楊光磊告白：我為什麼選擇提前退休？](https://www.bnext.com.tw/%22https://www.bnext.com.tw/article/84946/semiconductor-tsmc-yang/%22)
> 
> 



"\]


# 資料來源
2025/11/03: [AI搶了他們的工作！哈佛研究：愛用AI的企業不愛找小菜鳥，中等大學畢業比後段班更沒頭路](https://www.bnext.com.tw/article/84943/ai-seniority-job) 