---
新聞來源: "NVIDIA 台灣官方部落格"
published: 2025-10-29
---
# NVIDIA 推出 NVQLink，為 17 家量子開發商與 9 間科學實驗室串連量子與 GPU 運算
- [Email](https://blogs.nvidia.com.tw/blog/nvidia-nvqlink-quantum-gpu-computing/#ea-share-count-email)

- NVIDIA NVQLink 高速互連串連量子處理器與全球頂尖的超級運算實驗室，包括布魯克黑文國家實驗室、費米實驗室、勞倫斯伯克利國家實驗室、洛斯阿拉莫斯國家實驗室、麻省理工學院林肯實驗室、橡樹嶺國家實驗室、西北太平洋國家實驗室與桑迪亞國家實驗室。
- NVQLink 為量子研究人員提供強大系統，用於大規模量子運算與量子錯誤修正所需的控制演算法。
- NVQLink 能讓研究人員建置量子-經典混合式系統，加速化學與材料科學的新一代應用。

NVIDIA 今天宣布推出 [NVIDIA NVQLink™](https://www.nvidia.com/en-us/solutions/quantum-computing/nvqlink/) ，一款可將 GPU 運算的極致效能與量子處理器緊密結合的開放式系統架構，用於打造加速量子超級電腦。

由來自布魯克黑文國家實驗室（Brookhaven National Laboratory）、費米實驗室（Fermi Laboratory）、勞倫斯伯克利國家實驗室（Lawrence Berkeley National Laboratory）、洛斯阿拉莫斯國家實驗室（Los Alamos National Laboratory）、麻省理工學院林肯實驗室 （MIT Lincoln Laboratory）和美國能源部旗下橡樹嶺國家實驗室（Oak Ridge National Laboratory）、西北太平洋國家實驗室（Pacific Northwest National Laboratory）與桑迪亞國家實驗室（Sandia National Laboratories）等國家實驗室中頂尖的超級運算中心研究人員，共同指導 NVQLink 的開發，協助加速量子運算新一代的研究工作。NVQLink 提供開放式的量子整合方案，支援 17 家量子處理器（QPU）製造商、5 家控制器製造商及 9 間美國國家實驗室。

量子位元（Qubit）是量子電腦的基本資訊單位，能以傳統電腦無法達成的方式處理資訊。然而，量子位元非常脆弱且易出錯，因此需要藉由複雜的校準、量子錯誤修正及其他控制演算法才能正常運作。

這些演算法必須透過極高要求的低延遲、高輸送量連線至傳統超級電腦，以即時追蹤修正量子位元錯誤，進而實現具影響力的量子應用。NVQLink 正是提供這種互連技術，為未來跨產業的變革性應用奠定運算環境。

NVIDIA 創辦人暨執行長黃仁勳表示：「在不久後的將來，每部 NVIDIA GPU 科學超級電腦都將採用混合式架構，與量子處理器緊密結合，以拓展運算的可能性。NVQLink是連接量子與經典超級電腦的羅塞塔石碑（Rosetta Stone），將兩者整合為單一且一致的系統，象徵量子-GPU 運算時代的開端。」

美國國家實驗室在能源部的領導下，將運用 NVIDIA 的 NVQLink 技術在量子運算領域實現新突破。

美國能源部長 Chris Wright 表示：「要保持美國在高效能運算領域的領先地位，我們必須搭建通往下一個運算時代的橋樑：加速量子超級運算。我們的國家實驗室、新創公司，以及像 NVIDIA 這樣的產業合作夥伴之間的深度合作是這項使命的核心，而 NVIDIA NVQLink 提供了將世界級的 GPU 超級電腦與新興量子處理器相互結合的關鍵技術，打造出我們解決當代重大科學挑戰所需的強大系統。」

NVQLink 將量子處理器和控制硬體系統的各種方法直接連接至人工智慧（AI）超級運算，提供統一且開箱即用的解決方案，助力量子研究人員克服在擴展硬體時所面臨的關鍵整合挑戰。

透過超級運算中心、量子硬體製造商與量子控制系統供應商的共同貢獻下，NVQLink 建立了推動控制、校準、量子錯誤修正及混合應用開發等關鍵領域取得突破，為量子應用邁向實用奠定根基。

研究人員與開發人員可透過 NVQLink 與 [NVIDIA CUDA-Q](https://developer.nvidia.com/cuda-q) ™ 軟體平台的整合，開發及測試能無縫整合 CPU、GPU 與量子處理器的應用，協助產業為未來的量子-經典混合式超級電腦做好準備。

為 NVQLink 做出貢獻的合作夥伴包括量子硬體製造商 [Alice & Bob](https://alice-bob.com/newsroom/alice-bob-accelerates-fault-tolerant-quantum-computing-with-nvidia-nvqlink/) 、 [Anyon Computing](https://www.anyoncomputing.com/post/accelerated-quantum-ai-supercomputer) 、Atom Computing、 [Diraq](https://diraq.com/newsdesk/diraq-s-ultrafast-qubits-accelerated-by-nvidia-nvq-link) 、Infleqtion、IonQ、 [IQM Quantum Computers](https://meetiqm.com/press-releases/iqm-and-zurich-instruments-collaborate-with-nvidia-on-nvqlink-to-enable-scalable-quantum-error-correction) 、 [ORCA Computing](https://orcacomputing.com/orca-computing-a%E2%80%A6h-nvidia-nvqlink/) 、 [Oxford Quantum Circuits](http://oqc.tech/company/newsroom/oqc-advances-integration-of-quantum-computing-with-nvidia-nvqlink) 、 [Pasqal](https://www.pasqal.com/newsroom/pasqal-advances-hybrid-quantumai-computing-with-nvidia-nvqlink/) 、 [Quandela](https://www.quandela.com/resources/blog/nvidia-nvqlink-quantum-gpu-computing) 、Quantinuum、Quantum Circuits、 [Quantum Machines](https://www.quantum-machines.co/press-release/quantum-machines-announces-nvidia-nvqlink-integration-extending-real-time-quantum-classical-computing-solution/) 、Quantum Motion、QuEra、 [Rigetti](https://www.globenewswire.com/NewsRoom/ReleaseNg/7212033) 、SEEQC 與 Silicon Quantum Computing，以及量子控制系統供應商，包括 [Keysight Technologies](https://www.keysight.com/us/en/about/newsroom/news-releases/2025/1028_pr25-125-keysight-to-showcase-quantum-ai-collaboration-at-GTC-2025-with-nvidia-nvqlink.html) 、Quantum Machines、 [Qblox](https://qblox.com/newsroom/qblox-accelerates-utility-scale-quantum-computing-with-nvidia) 、QubiC 與 Zurich Instruments。

## 上市時程

若對 NVIDIA NVQLink 感興趣的量子製造商與超級運算中心，可在 [此網頁](https://www.nvidia.com/en-us/solutions/quantum-computing/nvqlink/) 註冊申請使用權限。

[*觀看 NVIDIA 創辦人暨執行長黃仁勳在 NVIDIA GTC DC大會的主題演講*](https://www.nvidia.com/gtc/dc/keynote/) *，深入瞭解 NVIDIA 與合作夥伴如何推動美國 AI 創新。*

**關於 NVIDIA**

[NVIDIA](https://www.nvidia.com/) （輝達）為加速運算領域的先驅。

**NVIDIA前瞻性聲明**  
本新聞稿根據目前預期所做出的前瞻性聲明，包含但不限於：在不久後的將來，每部 NVIDIA GPU 科學超級電腦都將採用混合式架構，與量子處理器緊密結合，以拓展運算的可能性；NVQLink是連接量子與經典超級電腦的羅塞塔石碑，將兩者整合為單一且一致的系統，象徵量子-GPU 運算時代的開端；NVIDIA 產品、服務和技術的優勢、影響、效能與可用性；對 NVIDIA 第三方安排的期望，包括對其協作夥伴與合作夥伴的期望；對技術開發的期望；以及其他非歷史事實的前瞻性聲明，依據修訂後的 1933 年《證券法》第 27A 條，以及修訂後的 1934 年《證券交易法》第 21E 條規定，這些聲明係根據管理階層的信念與假設，以及管理階層目前可取得的資訊，並受這些條款所制定的「安全港」約束，同時面臨各種風險與不確定性，實際結果可能與預期落差極大。可能導致實際結果差異極大的重要因素包括：全球經濟狀況與政局；NVIDIA 對第三方製造、組裝、封裝與測試 NVIDIA 產品的依賴；技術發展與競爭的影響；新產品與技術開發，或是對 NVIDIA 現有產品與技術的改良；NVIDIA 產品或 NVIDIA 合作夥伴產品的市場接受度；設計、製造或軟體瑕疵；消費者喜好或需求變動；產業標準與介面改變；NVIDIA 的產品或技術整合至系統時，發生意外的效能損失；適用法律與法規改變，以及 NVIDIA 不定時向證券交易委員會（SEC）呈報之最新報告中詳述的其他因素，包括但不限於 Form 10-K 年度報告和 Form 10-Q 季度報告詳述的因素。向 SEC 呈報的報告複本已在公司網站發布，可以向 NVIDIA 免費索取。這些前瞻性聲明不保證未來效能，且僅反映本文發布日期的情況，而且除法律規定，NVIDIA 不承擔任何義務，無須為反映未來事件或情況而更新這些前瞻性聲明。

©本文為NVIDIA 公司 2025版權所有，並保留所有權利。NVIDIA、NVIDIA 標誌、CUDA-Q 與 NVQLink 是 NVIDIA 公司在美國及其他地區的商標及（或）註冊商標。所有其他公司及產品名稱乃為所屬個別公司之商標。功能、訂價、出貨時程和規格之變更不會另行通知。

# 資料來源
2025/10/29: [NVIDIA 推出 NVQLink，為 17 家量子開發商與 9 間科學實驗室串連量子與 GPU 運算](https://blogs.nvidia.com.tw/blog/nvidia-nvqlink-quantum-gpu-computing/) 