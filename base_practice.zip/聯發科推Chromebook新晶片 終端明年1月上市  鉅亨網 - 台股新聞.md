---
新聞來源: 鉅亨網
published: 2025-10-29
---
# 聯發科推Chromebook新晶片 終端明年1月上市 | 鉅亨網 - 台股新聞
聯發科 ([2454-TW](https://www.cnyes.com/twstock/2454)) 今 (29) 日宣布推出 Kompanio 540，專為輕薄、輕盈便攜 Chromebook 所打造，電池續航力較上一代產品增加 35%，預計搭載該顆新晶片的 Chromebook 將在明年 1 月正式上市。

![cover image of news article](https://cimg.cnyes.cool/prod/news/6209104/l/27cc4ef35b33222b0c3220e83645ff98.jpg)

聯發科資料照。(圖：業者提供)

Google ChromeOS 副總經理 John Maletis 表示，聯發科 Kompanio 540 賦能更多 Chromebook，為更多用戶帶來效能與能效的完美平衡，讓使用者能夠輕鬆應付整天的工作與娛樂。

‌  

聯發科 Kompanio 540 搭載八核心處理器，包含兩顆 Arm Cortex-A78、雙核心圖形處理器，並支援高階 LPDDR5 記憶體與 UFS 3.1 快閃記憶體儲存，讓整體效能更為流暢，且能輕鬆應付多任務操作。學生得以在瀏覽網頁、串流影音或玩遊戲等日常任務間，零延遲地順暢切換。

聯發科 Kompanio 540 也能確保在執行 STEM、Tinkercad 和 Minecraft 教育版等高需求應用程式時，依然維持流暢性能，同時內建強大的影片解碼器，提供流暢、省電的高解析度串流體驗，即便外接至電視放映，也不會耗盡電池電量。

聯發科 Kompanio 540 電池續航力較上一代產品增加 35%，讓 Chromebook 用戶擁有全天候的高效生產力。此外，其高效能省電設計支援無風扇高效運作，既安靜又不影響學習。搭載 Kompanio 的 Chromebook 不僅更輕巧、運作時更低溫，讓用戶實現真正的隨身攜帶，且能隨時隨地暢享運算體驗。

# 資料來源
2025/10/29: [聯發科推Chromebook新晶片 終端明年1月上市 | 鉅亨網 - 台股新聞](https://news.cnyes.com/news/id/6209104) 