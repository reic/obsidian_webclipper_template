---
新聞來源: "T客邦"
published: 2025-10-31
---
# OpenAI 放大絕！2028 年 AI 研究員報到，以後論文自己寫？
T客邦為提供您更多優質的內容，採用網站分析技術，若您點選「我同意」或繼續瀏覽本網站，即表示您同意我們的 [隱私權政策](https://www.techbang.com/pages/privacy) 。

![OpenAI 放大絕！2028 年 AI 研究員報到，以後論文自己寫？](https://cdn1.techbang.com/system/excerpt_images/126226/original/7372eb996433bf595ee275f24c28844e.jpg?1761809206)

OpenAI 執行長 Sam Altman 日前在直播中透露，該公司目標在 **2028 年前打造出能完全自動化執行研究任務的 AI 研究員** 。他補充，最快在 2026 年 9 月前，OpenAI 就能實現具備「實習研究助理」水準的 AI 模型。

根據 Altman 說法，這個所謂「合法的 AI 研究員」指的並非單純輔助人類，而是能 **獨立完成大型研究計畫** 的系統，等於將 AI 真正投入科研第一線。

![OpenAI 放大絕！2028 年 AI 研究員報到，以後論文自己寫？](https://cdn0.techbang.com/system/images/763421/original/d432ca44871997757131717a13f737fc.jpg?1761809164)

### OpenAI 內部模型已達高效水準，可執行 5 小時等級的複雜任務

OpenAI 首席科學家 Jakub Pachocki 表示，目前的 AI 模型已可在國際數學奧林匹亞這類競賽中與頂尖人類選手匹敵，並具備完成約 5 小時研究任務的能力。他認為，未來十年內，AI 可能會邁向「 **超級智慧** 」的階段，也就是在多數核心領域全面超越人類能力。

為了實現這個目標，OpenAI 正透過強化演算法創新，並 **大幅提升「推理時運算量」（Test-time compute）** ，意即給模型更多資源與時間去思考與推理。Pachocki 預測，未來重大科學突破，可能需要整座資料中心等級的資源來解決單一問題。

### 組織轉型與基礎建設投資，為未來鋪路

本次宣布也緊接著 OpenAI 完成組織結構重整，從非營利機構轉型為公益型公司（Public Benefit Corporation），可進一步解除募資與資源使用上的限制，加速整體開發進程。

Altman 表示，新的架構讓公司在制度上更能支撐 AI 助理與研究相關的研發進展。 **非營利的 OpenAI 基金會** 仍將持有公司 **26% 的股份** ，並主導研究方向。該基金會目前已獲得 **2,500 億美元** （約新台幣 **80 兆元** ）的資金承諾，將聚焦在用 AI 解決疾病等科研任務，並協助制定 AI 安全與倫理規範。

此外，Altman 也透露，OpenAI 計畫未來幾年擁有 **30 GW（吉瓦）運算能力的資料中心** ，對應的總體投資高達 **1.4 兆美元** （約新台幣 **44 兆元** ）。他進一步補充：「我們的目標是每年投入高達 **1 兆美元** （約新台幣 **32 兆元** ）在基礎設施建設上，推動科技領域的根本變革。」

OpenAI 強調，開發自動化 AI 研究員是公司長期戰略的一部分，希望透過 AI 的力量 **突破人類目前無法解決的複雜問題** ，推動包括醫學、物理與技術開發等多個產業的創新。

- **延伸閱讀： [OpenAI 網羅前 Apple「捷徑」團隊，為 ChatGPT 注入 macOS 深度整合](https://www.techbang.com/posts/126135-openai-hires-apple-shortcuts-team-for-chatgpt-macos)**
- **延伸閱讀： [馬斯克又喊 AGI 快來了，OpenAI 研究員嘲諷「這是他第四次宣布」](https://www.techbang.com/posts/126094-musk-agi-prediction-met-with-skepticism)**
- **延伸閱讀： [OpenAI 收緊 Sora 內容規範，將與演員工會合作防堵 AI 深偽風險](https://www.techbang.com/posts/126091-openai-sora-content-policy-ai-deepfake-risk)**

[超便宜散熱膏竟是「硬體殺手」！韓國 SGT-4 驚傳腐蝕 CPU、還恐危害健康 | T客邦](https://www.techbang.com/posts/126119-cheap-thermal-paste-corrodes-cpu?utm_source=instag&utm_medium=link "超便宜散熱膏竟是「硬體殺手」！韓國 SGT-4 驚傳腐蝕 CPU、還恐危害健康 | T客邦")

[智慧型手機拆光看清楚：24個重要元件解說，認識手機的內涵 | T客邦](https://www.techbang.com/posts/10679-intelligent-phone-remove-light-clear-rookie-appearance-insiders-look-at-dismantling-cell-phone-inherent-how-much-do-you-know-the-computer-96-issues-cover-story-the-king-part2?utm_source=instag&utm_medium=link "智慧型手機拆光看清楚：24個重要元件解說，認識手機的內涵 | T客邦")

[iPhone 17 全系列螢幕得分151分未進前20，DxOMark護眼認證加持但仍不敵Pixel、三星旗艦 | T客邦](https://www.techbang.com/posts/126170-iphone-17-dxomark-display-score?utm_source=instag&utm_medium=link "iPhone 17 全系列螢幕得分151分未進前20，DxOMark護眼認證加持但仍不敵Pixel、三星旗艦 | T客邦")

[英特爾14A製程進度大超前！性能超過18A，潛在客戶搶先參與測試 | T客邦](https://www.techbang.com/posts/126141-intel-14a-process-performance-exceeds-18a?utm_source=instag&utm_medium=link "英特爾14A製程進度大超前！性能超過18A，潛在客戶搶先參與測試 | T客邦")

[初音未來「硬體」來襲！Asus ROG x Hatsune Miku聯名快閃店開幕，展出多樣產品與改裝主機 | T客邦](https://www.techbang.com/posts/126130-asus-rog-hatsune-miku-pop-up-store?utm_source=instag&utm_medium=link "初音未來「硬體」來襲！Asus ROG x Hatsune Miku聯名快閃店開幕，展出多樣產品與改裝主機 | T客邦")

[iOS 26.1「液態玻璃」實測報告：切換成「色調」模式對續航幾乎沒影響 | T客邦](https://www.techbang.com/posts/126147-ios-26-1-liquid-glass-battery-test?utm_source=instag&utm_medium=link "iOS 26.1「液態玻璃」實測報告：切換成「色調」模式對續航幾乎沒影響 | T客邦")

![cnBeta](https://cdn0-i.techbang.com/system/avatars/cnbeta/medium/de619ec09b88533169bb6c86724d21b4.jpg "cnBeta")

[送【10個ChatGPT的好工具】電子書 ![Line brand icon](https://cdn2.techbang.com/assets/imgs/line_brand_icon-13bdbbc3495798600163c4c4075095775bccc61fde624ea34cce90ee06806e34.png)](https://lin.ee/7m0Thwg) 

使用 Facebook 留言

# 資料來源
2025/10/31: [OpenAI 放大絕！2028 年 AI 研究員報到，以後論文自己寫？](https://www.techbang.com/posts/126226-openai-ai-researcher-2028-infrastructure-investment) 