---
新聞來源: "NVIDIA 台灣官方部落格"
published: 2025-10-28
---
# Palantir 與 NVIDIA 合作推動 AI 落地營運，將企業資料轉化為動態決策智慧
- [Email](https://blogs.nvidia.com.tw/blog/nvidia-palantir-ai-enterprise-data-intelligence/#ea-share-count-email)

**【** **2025** **年** **10** **月** **28** **日，美國** **華盛頓特區訊】** NVIDIA 今日宣布與 [Palantir](https://blog.palantir.com/ai-infrastructure-and-ontology-78b86f173ea6) Technologies Inc. 合作，共同打造首個針對營運型人工智慧（operational AI）的整合技術堆疊，涵蓋分析功能、參考工作流程、自動化功能，以及可客製化的專用AI代理，以加速並最佳化複雜的企業與政府系統。

[Palantir AI 平台](https://www.palantir.com/platforms/foundry/foundry-ontology/) （AIP）核心的 [Palantir Ontology](https://www.palantir.com/platforms/aip/) 將整合 NVIDIA GPU 加速的資料處理與路徑最佳化函式庫、開源模型及加速運算能力。Ontology 與 NVIDIA AI的結合將提供客戶營運型 AI 所需的先進情境感知推理能力。

使用可客製化技術堆疊的企業將能夠利用自身資料，驅動特定領域的自動化流程與AI代理，滿足零售業、醫療機構、金融服務與公部門等高度複雜的營運環境需求。

NVIDIA 創辦人暨執行長黃仁勳表示：「Palantir 與 NVIDIA 擁有共同的願景：讓 AI 發揮實際效益，將企業資料轉化為決策智慧。透過結合 Palantir 強大的 AI 平台、NVIDIA CUDA-X 加速運算及 Nemotron 開源 AI 模型，我們正在打造新一代引擎，以驅動運行全球最複雜之工業和營運流程的 AI 專用應用與代理程式。」

Palantir Technologies 共同創辦人暨執行長 Alex Karp 表示：「Palantir 致力於部署能為客戶帶來即時且非對稱價值的 AI 解決方案。我們很榮幸能和 NVIDIA 合作，將我們的 AI 決策智慧系統，與全球最先進的 AI 基礎架構結合在一起。」

**Lowe’s 攜手 Palantir、NVIDIA 攜手開創 AI 驅動物流技術**

Lowe’s 是率先採用 Palantir 與 NVIDIA 整合技術堆疊的企業之一，目前正打造其全球供應鏈網路的數位複製品（digital replica），以實現動態且持續的 AI 最佳化。這項技術能強化供應鏈的靈活性，同時提升成本效益與顧客滿意度。

Lowe’s 執行副總裁暨數位與資訊長 Seemantini Godbole 表示：「現代供應鏈是極其複雜且動態的系統，而 AI 將是協助 Lowe’s 快速應對變化與最佳化營運的關鍵。即使是微小的需求變化，也可能對全球網路中產生連鎖反應。透過將 Palantir 技術與 NVIDIA AI 相結合，Lowe’s 正在重新塑造零售物流，讓我們每天都能更好地服務顧客。」

**提升營運智慧能力**

Palantir AIP 的工作負載在最複雜的合規領域運行，需達到最高的隱私與資料安全標準。AIP 核心的 Ontology 透過將複雜的資料與邏輯，組織成相互關聯的虛擬物件、連結與動作，從而建立出企業的數位複製品，對應現實世界中的概念與其關聯性。

這為企業提供了一個具備 AI 能力的智慧營運系統，透過業務流程自動化來提升效率。

為了推進 AI 時代的企業智慧，NVIDIA 的資料處理、AI 軟體、開源模型與加速運算技術現已原生整合至 Ontology 與 AIP 中，並可直接透過這些平台使用。客戶可透過 Ontology使用 [NVIDIA CUDA-X](https://www.nvidia.com/en-us/technologies/cuda-x/) ™ 資料科學函式庫與加速運算，推動即時、AI 驅動的決策制定，應對複雜且關鍵的業務流程。

[NVIDIA AI Enterprise](https://www.nvidia.com/en-us/data-center/products/ai-enterprise/) 平台，包括 [NVIDIA cuOpt](https://www.nvidia.com/en-us/ai-data-science/products/cuopt/) ™ 決策最佳化軟體，將協助企業運用 AI 以實現動態供應鏈管理。

[NVIDIA Nemotron](https://www.nvidia.com/en-us/ai-data-science/foundation-models/nemotron/) ™ 推理與 [NVIDIA NeMo Retriever](https://developer.nvidia.com/nemo-retriever) ™ 開源模型將使企業能快速建構以 Ontology 為基礎的 AI 代理。

NVIDIA 和 Palantir 也正協同將 [NVIDIA Blackwell](https://www.nvidia.com/en-us/data-center/technologies/blackwell-architecture/) 架構導入 Palantir AIP，藉此強化從資料處理、分析，到模型開發、微調與 AI 上線的完整流程，並支援具備長期思考與推理能力的代理。企業將能夠在 NVIDIA AI 工廠中運行 AIP，以實現最佳化的加速。

此外，Palantir AIP 也將支援今日另行發布的 [NVIDIA 政府版 AI 工廠參考設計](https://blogs.nvidia.com/blog/us-technology-leaders-ai-factory-design-government) 。

在 NVIDIA GTC DC大會上，與會者可報名參加 Palantir 與 NVIDIA 於美東時間 10 月 29 日（星期三）下午 3:15 至 5:00 舉辦的實作工作坊，深入瞭解營運型 AI 的實際應用。

[*觀看* *NVIDIA* *創辦人暨執行長黃仁勳在* *NVIDIA GTC DC* *大會的主題演講*](https://www.nvidia.com/gtc/dc/keynote/) *，深入瞭解* *NVIDIA* *與合作夥伴如何推動美國* *AI* *創新。*

**關於 NVIDIA**

[NVIDIA](https://www.nvidia.com/) （輝達）為加速運算領域的先驅。

**NVIDIA前瞻性聲明**  
本新聞稿根據目前預期所做出的前瞻性聲明，包含但不限於：透過結合 Palantir 強大的 AI 平台、NVIDIA CUDA-X 加速運算及 Nemotron 開源 AI 模型，NVIDIA 正在打造新一代引擎，以驅動運行全球最複雜之工業和營運流程的 AI 專用應用與代理程式；NVIDIA 產品、服務和技術的優勢、影響、效能與可用性；對 NVIDIA 第三方安排的期望，包括對其協作夥伴與合作夥伴的期望；對技術開發的期望；以及其他非歷史事實的前瞻性聲明，依據修訂後的 1933 年《證券法》第 27A 條，以及修訂後的 1934 年《證券交易法》第 21E 條規定，這些聲明係根據管理階層的信念與假設，以及管理階層目前可取得的資訊，並受這些條款所制定的「安全港」約束，同時面臨各種風險與不確定性，實際結果可能與預期落差極大。可能導致實際結果差異極大的重要因素包括：全球經濟狀況與政局；NVIDIA 對第三方製造、組裝、封裝與測試 NVIDIA 產品的依賴；技術發展與競爭的影響；新產品與技術開發，或是對 NVIDIA 現有產品與技術的改良；NVIDIA 產品或 NVIDIA 合作夥伴產品的市場接受度；設計、製造或軟體瑕疵；消費者喜好或需求變動；產業標準與介面改變；NVIDIA 的產品或技術整合至系統時，發生意外的效能損失；適用法律與法規改變，以及 NVIDIA 不定時向證券交易委員會 (SEC) 呈報之最新報告中詳述的其他因素，包括但不限於 Form 10-K 年度報告和 Form 10-Q 季度報告詳述的因素。向 SEC 呈報的報告複本已在公司網站發布，可以向 NVIDIA 免費索取。這些前瞻性聲明不保證未來效能，且僅反映本文發布日期的情況，而且除法律規定，NVIDIA 不承擔任何義務，無須為反映未來事件或情況而更新這些前瞻性聲明。

©本文為NVIDIA 公司 2025版權所有，並保留所有權利。NVIDIA、NVIDIA 標誌、CUDA-X、cuOpt、NVIDIA NeMo Retriever 與 NVIDIA Nemotron 是NVIDIA 公司在美國及其他地區的商標及（或）註冊商標。所有其他公司及產品名稱乃為所屬個別公司之商標。功能、訂價、出貨時程和規格之變更不會另行通知。

# 資料來源
2025/10/28: [Palantir 與 NVIDIA 合作推動 AI 落地營運，將企業資料轉化為動態決策智慧](https://blogs.nvidia.com.tw/blog/nvidia-palantir-ai-enterprise-data-intelligence/) 